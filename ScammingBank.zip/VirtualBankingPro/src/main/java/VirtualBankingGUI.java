package com.virtualbank;

import javax.swing.*;

public class VirtualBankingGUI extends JFrame {

    public VirtualBankingGUI() {
        setTitle("Virtual Banking Pro");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
    }
}
