package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class OverdraftServicesScreen extends JFrame {

    private JComboBox<String> amountBox;
    private JComboBox<String> reasonBox;
    private JComboBox<String> employerBox;
    private JComboBox<String> yearsBox;
    private JComboBox<String> monthsBox;
    private JTextField incomeField;
    private JComboBox<String> durationBox;

    public OverdraftServicesScreen(String username) {
        setTitle("Overdraft Application");
        setSize(520, 530);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(20, 25, 45));

        JLabel titleLabel = new JLabel("Apply for Overdraft");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 20, 300, 30);
        add(titleLabel);

        JLabel amountLabel = new JLabel("Overdraft Amount:");
        amountLabel.setForeground(Color.WHITE);
        amountLabel.setBounds(60, 80, 150, 25);
        add(amountLabel);

        String[] amounts = {"£200", "£500", "£800", "£1,200", "£2,000"};
        amountBox = new JComboBox<>(amounts);
        amountBox.setBounds(220, 80, 200, 30);
        add(amountBox);

        JLabel reasonLabel = new JLabel("Reason:");
        reasonLabel.setForeground(Color.WHITE);
        reasonLabel.setBounds(60, 130, 150, 25);
        add(reasonLabel);

        String[] reasons = {"-- Select reason --", "Unexpected expenses", "Emergency repairs", "Monthly gap", "Travel costs", "Other"};
        reasonBox = new JComboBox<>(reasons);
        reasonBox.setBounds(220, 130, 200, 30);
        add(reasonBox);

        JLabel employerLabel = new JLabel("Employer:");
        employerLabel.setForeground(Color.WHITE);
        employerLabel.setBounds(60, 180, 150, 25);
        add(employerLabel);

        String[] employers = {"-- Select employer --", "Amazon", "NHS", "Tesco", "Lidl", "Other"};
        employerBox = new JComboBox<>(employers);
        employerBox.setBounds(220, 180, 200, 30);
        add(employerBox);

        JLabel durationLabel = new JLabel("Employment Duration:");
        durationLabel.setForeground(Color.WHITE);
        durationLabel.setBounds(60, 230, 150, 25);
        add(durationLabel);

        String[] years = new String[31];
        for (int i = 0; i <= 30; i++) years[i] = i + " years";
        yearsBox = new JComboBox<>(years);
        yearsBox.setBounds(220, 230, 95, 30);
        add(yearsBox);

        String[] months = new String[12];
        for (int i = 0; i <= 11; i++) months[i] = i + " months";
        monthsBox = new JComboBox<>(months);
        monthsBox.setBounds(325, 230, 95, 30);
        add(monthsBox);

        JLabel incomeLabel = new JLabel("Monthly Income (£):");
        incomeLabel.setForeground(Color.WHITE);
        incomeLabel.setBounds(60, 280, 150, 25);
        add(incomeLabel);

        incomeField = new JTextField();
        incomeField.setBounds(220, 280, 200, 30);
        add(incomeField);

        JLabel termLabel = new JLabel("Overdraft Duration:");
        termLabel.setForeground(Color.WHITE);
        termLabel.setBounds(60, 330, 150, 25);
        add(termLabel);

        String[] durations = {"3 months", "6 months", "12 months", "24 months"};
        durationBox = new JComboBox<>(durations);
        durationBox.setBounds(220, 330, 200, 30);
        add(durationBox);

        JButton submitButton = new JButton("Submit Application");
        submitButton.setBounds(160, 400, 180, 40);
        submitButton.setBackground(new Color(0, 120, 215));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String amount = (String) amountBox.getSelectedItem();
                String reason = (String) reasonBox.getSelectedItem();
                String employer = (String) employerBox.getSelectedItem();
                String years = (String) yearsBox.getSelectedItem();
                String months = (String) monthsBox.getSelectedItem();
                String income = incomeField.getText().trim();
                String duration = (String) durationBox.getSelectedItem();

                if (reasonBox.getSelectedIndex() == 0 || employerBox.getSelectedIndex() == 0 || income.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please complete all fields.");
                    return;
                }

                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
                String entry = username + "|" + amount + "|" + reason + "|" + duration + "|Pending|Overdraft|" +
                        employer + "|" + years + " " + months + "|" + timestamp + "|Pending";

                try {
                    BufferedWriter userWriter = new BufferedWriter(new FileWriter("overdraft_applications.txt", true));
                    userWriter.write(entry);
                    userWriter.newLine();
                    userWriter.close();

                    BufferedWriter adminWriter = new BufferedWriter(new FileWriter("admin2_overdraft_requests.txt", true));
                    adminWriter.write(entry);
                    adminWriter.newLine();
                    adminWriter.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                dispose();
                new OverdraftStatusScreen(username);
            }
        });

        setVisible(true);
    }
}
