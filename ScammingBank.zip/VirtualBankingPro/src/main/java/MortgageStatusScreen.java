package screens;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MortgageStatusScreen extends JFrame {

    private String currentUser;
    private JTextArea statusArea;

    public MortgageStatusScreen(String username) {
        this.currentUser = username;
        setTitle("Mortgage Status");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(20, 20, 20));

        JLabel titleLabel = new JLabel("Your Mortgage Status");
        titleLabel.setBounds(130, 20, 300, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        statusArea = new JTextArea();
        statusArea.setBounds(30, 70, 420, 330);
        statusArea.setEditable(false);
        statusArea.setForeground(Color.GREEN);
        statusArea.setBackground(new Color(30, 30, 30));
        statusArea.setFont(new Font("Arial", Font.PLAIN, 14));
        statusArea.setLineWrap(true);
        statusArea.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(statusArea);
        scroll.setBounds(30, 70, 420, 330);
        add(scroll);

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(190, 420, 100, 30);
        closeButton.setBackground(new Color(0, 120, 255));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose());
        add(closeButton);

        loadMortgageStatus();
        setVisible(true);
    }

    private void loadMortgageStatus() {
        List<String> entries = new ArrayList<>();
        File file = new File("mortgage_applications.txt");
        if (!file.exists()) {
            statusArea.setText("No mortgage application found.");
            return;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(currentUser + "|")) {
                    entries.add(line);
                }
            }
        } catch (IOException e) {
            statusArea.setText("Error loading mortgage data.");
            return;
        }
        if (entries.isEmpty()) {
            statusArea.setText("No mortgage application found.");
        } else {
            String[] last = entries.get(entries.size() - 1).split("\\|");
            if (last.length >= 10) {
                String summary = "Property Value: £" + last[1] + "\nDeposit: £" + last[2] + "\nTerm: " + last[3] + " years\nEmployment: " + last[4] + "\nIncome: £" + last[5] + "\nExpenses: £" + last[6] + "\nPurpose: " + last[7] + "\nApplied: " + last[8] + "\nStatus: " + last[9];
                statusArea.setText(summary);
            } else {
                statusArea.setText("Invalid mortgage data format.");
            }
        }
    }
}
