package com.virtualbank;

import com.virtualbank.ui.LoginCard;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;

public class LoginScreen extends JFrame {

    public static String currentUser;

    public LoginScreen() {
        setTitle("Login");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(backgroundColor);

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH)));
        logo.setBounds(230, 10, 130, 130);

        JButton backButton = new JButton();
        backButton.setIcon(new ImageIcon(getClass().getResource("/icons/arrow_back_24dp_1F1F1F.png")));
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(100, 145, 48, 48);
        backButton.addActionListener(e -> {
            dispose();
            new HomeScreen().setVisible(true);
        });

        LoginCard loginCard = new LoginCard();
        loginCard.loginButton.setText("Log on now");
        loginCard.setBounds(100, 140, 400, 237);

        JLabel infoTitle = new JLabel("Don’t have Internet Banking yet?");
        infoTitle.setForeground(Color.WHITE);
        infoTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        infoTitle.setHorizontalAlignment(SwingConstants.CENTER);
        infoTitle.setBounds(100, 380, 400, 20);

        JLabel infoText = new JLabel("<html><div style='text-align: center;'>Let’s get you banking online. First, we’ll ask for your account details. You’ll find these on cards, statements, and bank documents.</div></html>");
        infoText.setForeground(Color.WHITE);
        infoText.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        infoText.setHorizontalAlignment(SwingConstants.CENTER);
        infoText.setBounds(100, 400, 400, 40);

        JButton setupButton = new JButton("Set up Internet Banking");
        setupButton.setBackground(Color.WHITE);
        setupButton.setForeground(Color.BLACK);
        setupButton.setFocusPainted(false);
        setupButton.setBounds(190, 450, 220, 35);
        setupButton.addActionListener(e -> {
            dispose();
            new RegisterScreen().setVisible(true);
        });

        loginCard.loginButton.addActionListener(e -> {
            String username = loginCard.usernameField.getText();
            String password = new String(loginCard.passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter both username and password", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (username.equals("admin") && password.equals("admin")) {
                currentUser = username;
                new AdminDashboard().setVisible(true);
                dispose();
                return;
            }

            if (username.equals("admin2") && password.equals("admin2")) {
                currentUser = username;
                new Admin2Dashboard(null, username).setVisible(true);
                dispose();
                return;
            }

            boolean found = false;
            boolean blocked = false;

            try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(";");
                    if (parts.length >= 5 && parts[0].equals(username) && parts[2].equals(password)) {
                        if (parts[4].equalsIgnoreCase("blocked")) {
                            blocked = true;
                        } else {
                            found = true;
                        }
                        break;
                    }
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error reading user database", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (blocked) {
                ImageIcon logoIcon = new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
                JDialog dialog = new JDialog(this, "Account Blocked", true);
                dialog.setSize(400, 280);
                dialog.setLayout(new BorderLayout());
                dialog.setUndecorated(false);
                dialog.setLocationRelativeTo(this);

                JPanel panel = new JPanel();
                panel.setBackground(new Color(30, 60, 90));
                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

                JLabel iconLabel = new JLabel(logoIcon);
                iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel messageLabel = new JLabel("Your account has been blocked.");
                messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                messageLabel.setForeground(Color.WHITE);
                messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

                JButton supportButton = new JButton("Contact Support");
                supportButton.setBackground(Color.DARK_GRAY);
                supportButton.setForeground(Color.WHITE);
                supportButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
                supportButton.setFocusPainted(false);
                supportButton.setAlignmentX(Component.CENTER_ALIGNMENT);
                supportButton.setMaximumSize(new Dimension(200, 35));
                supportButton.addActionListener(ev -> {
                    dialog.dispose();
                    new SupportTicketScreen(username).setVisible(true);
                });

                JButton okButton = new JButton("OK");
                okButton.setBackground(Color.BLACK);
                okButton.setForeground(Color.WHITE);
                okButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
                okButton.setFocusPainted(false);
                okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
                okButton.setMaximumSize(new Dimension(200, 35));
                okButton.addActionListener(ev -> dialog.dispose());

                panel.add(Box.createVerticalStrut(15));
                panel.add(iconLabel);
                panel.add(Box.createVerticalStrut(15));
                panel.add(messageLabel);
                panel.add(Box.createVerticalStrut(10));
                panel.add(supportButton);
                panel.add(Box.createVerticalStrut(5));
                panel.add(okButton);
                panel.add(Box.createVerticalStrut(15));

                dialog.add(panel);
                dialog.setResizable(false);
                dialog.setVisible(true);
                return;
            }

            if (found) {
                currentUser = username;
                UserService userService = new UserService();
                Dashboard.activeUser = userService.loadUser(username);
                ImageIcon logoIcon = new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
                JDialog dialog = new JDialog(this, "Welcome back!", true);
                dialog.setSize(400, 250);
                dialog.setLayout(new BorderLayout());
                dialog.setUndecorated(false);
                dialog.setLocationRelativeTo(this);

                JPanel panel = new JPanel();
                panel.setBackground(new Color(30, 60, 90));
                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

                JLabel iconLabel = new JLabel(logoIcon);
                iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel messageLabel = new JLabel("You’ve securely logged into your account.");
                messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                messageLabel.setForeground(Color.WHITE);
                messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

                JButton okButton = new JButton("OK");
                okButton.setBackground(Color.BLACK);
                okButton.setForeground(Color.WHITE);
                okButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
                okButton.setFocusPainted(false);
                okButton.setPreferredSize(new Dimension(300, 40));
                okButton.setMaximumSize(new Dimension(300, 40));
                okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
                okButton.addActionListener(ev -> {
                    dialog.dispose();
                    new Dashboard(username).setVisible(true);
                    dispose();
                });

                panel.add(Box.createVerticalStrut(15));
                panel.add(iconLabel);
                panel.add(Box.createVerticalStrut(15));
                panel.add(messageLabel);
                panel.add(Box.createVerticalStrut(20));
                panel.add(okButton);
                panel.add(Box.createVerticalStrut(15));

                dialog.add(panel);
                dialog.setResizable(false);
                dialog.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect username or password", "Login Failed", JOptionPane.ERROR_MESSAGE);
                loginCard.usernameField.setText("Username");
                loginCard.usernameField.setForeground(Color.GRAY);
                loginCard.passwordField.setText("Password");
                loginCard.passwordField.setForeground(Color.GRAY);
                loginCard.passwordField.setEchoChar((char) 0);
            }
        });

        mainPanel.add(logo);
        mainPanel.add(backButton);
        mainPanel.add(loginCard);
        mainPanel.add(infoTitle);
        mainPanel.add(infoText);
        mainPanel.add(setupButton);
        add(mainPanel);
    }
}
