package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class HomeScreen extends JFrame {

    public HomeScreen() {
        setTitle("Virtual Banking - Home");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundColor);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        content.add(Box.createVerticalStrut(30));

        JLabel logoLabel = new JLabel();
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("/icons/Scamming Bank.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH);
        logoLabel.setIcon(new ImageIcon(scaledImage));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(logoLabel);

        content.add(Box.createVerticalStrut(20));

        JLabel title = new JLabel("Welcome to Virtual Banking");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(title);

        content.add(Box.createVerticalStrut(40));

        JLabel loginLabel = new JLabel("Already a customer?");
        loginLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        loginLabel.setForeground(Color.WHITE);
        loginLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(loginLabel);

        content.add(Box.createVerticalStrut(8));

        JButton loginBtn = new JButton("Let’s get you logged on");
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginBtn.setBackground(Color.BLACK);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.setMaximumSize(new Dimension(300, 45));
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(loginBtn);

        content.add(Box.createVerticalStrut(30));

        JLabel registerLabel = new JLabel("Become a customer");
        registerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        registerLabel.setForeground(Color.WHITE);
        registerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(registerLabel);

        content.add(Box.createVerticalStrut(8));

        JButton registerBtn = new JButton("Open a bank account with us");
        registerBtn.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        registerBtn.setBackground(Color.WHITE);
        registerBtn.setFocusPainted(false);
        registerBtn.setMaximumSize(new Dimension(300, 45));
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(registerBtn);

        loginBtn.addActionListener(e -> {
            dispose();
            new LoginScreen().setVisible(true);
        });

        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterScreen().setVisible(true);
        });

        JPanel centerWrapper = new JPanel();
        centerWrapper.setOpaque(false);
        centerWrapper.add(content);
        mainPanel.add(centerWrapper, BorderLayout.CENTER);

        JLabel legalInfo = new JLabel("<html><u>Legal information</u></html>");
        legalInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        legalInfo.setForeground(Color.WHITE);
        legalInfo.setHorizontalAlignment(SwingConstants.CENTER);
        legalInfo.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        legalInfo.setCursor(new Cursor(Cursor.HAND_CURSOR));
        legalInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new LegalInfoScreen();
            }
        });

        mainPanel.add(legalInfo, BorderLayout.SOUTH);

        add(mainPanel);
    }
}
