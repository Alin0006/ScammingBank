package com.virtualbank;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Admin2Dashboard extends JFrame {

    private Dashboard dashboard;
    private String username;

    public Admin2Dashboard(Dashboard dashboard, String username) {
        this.dashboard = dashboard;
        this.username = username;
        setTitle("Admin Panel - Financial Services");
        setSize(780, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Credit Card", createApplicationPanel("creditcard_applications.txt", "creditcard_applications_processed.txt"));
        tabs.add("Loans", createApplicationPanel("loan_applications.txt", "loan_applications_processed.txt"));
        tabs.add("Mortgage", createMortgagePanel());
        tabs.add("Overdraft", createOverdraftPanel());

        JButton logoutButton = new JButton("Log Out");
        logoutButton.setBackground(new Color(50, 50, 50));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setMaximumSize(new Dimension(200, 35));
        logoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginScreen().setVisible(true);
        });

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(230, 235, 245));
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(tabs, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(230, 235, 245));
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.add(Box.createVerticalStrut(10));
        bottomPanel.add(logoutButton);
        bottomPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createOverdraftPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(panel);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        JPanel container = new JPanel(new BorderLayout());
        container.add(scroll, BorderLayout.CENTER);

        List<String> updatedLines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("overdraft_applications.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                updatedLines.add(line);
            }
        } catch (IOException ignored) {}

        for (String currentLine : updatedLines) {
            String[] parts = currentLine.split("\\|");
            if (parts.length >= 9) {
                String user = parts[0];
                String requested = parts[1];
                String reason = parts[2];
                String employer = parts[3];
                String income = parts[4];
                String expenses = parts[5];
                String purpose = parts[6];
                String date = parts[7];
                String status = parts[8];

                JPanel card = new JPanel();
                card.setLayout(new BorderLayout());
                card.setBackground(Color.WHITE);
                card.setBorder(new EmptyBorder(12, 15, 12, 15));
                card.setMaximumSize(new Dimension(720, 260));

                JTextArea area = new JTextArea();
                area.setEditable(false);
                area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                area.setBackground(Color.WHITE);
                area.setLineWrap(true);
                area.setWrapStyleWord(true);
                area.setRows(10);
                area.setText("User: " + user + "\nRequested: £" + requested + "\nReason: " + reason + "\nEmployer: " + employer + "\nIncome: £" + income + "\nExpenses: £" + expenses + "\nPurpose: " + purpose + "\nSubmitted: " + date + "\nStatus: " + status);

                JButton approveBtn = new JButton("Approve");
                approveBtn.setBackground(new Color(30, 130, 30));
                approveBtn.setForeground(Color.WHITE);
                approveBtn.addActionListener(e -> {
                    updateOverdraftStatus(user, date, "APPROVED");
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("overdraft_applications_processed.txt", true))) {
                        writer.write(user + "|" + requested + "|" + reason + "|" + employer + "|" + income + "|" + expenses + "|" + purpose + "|" + date + "|APPROVED");
                        writer.newLine();
                    } catch (IOException ex) {}
                    removeLineFromFile("overdraft_applications.txt", currentLine);
                    container.removeAll();
                    container.add(createOverdraftPanel(), BorderLayout.CENTER);
                    container.revalidate();
                    container.repaint();
                });

                JButton declineBtn = new JButton("Decline");
                declineBtn.setBackground(new Color(200, 30, 30));
                declineBtn.setForeground(Color.WHITE);
                declineBtn.addActionListener(e -> {
                    removeLineFromFile("overdraft_applications.txt", currentLine);
                    container.removeAll();
                    container.add(createOverdraftPanel(), BorderLayout.CENTER);
                    container.revalidate();
                    container.repaint();
                });

                JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                bottom.setBackground(Color.WHITE);
                bottom.add(approveBtn);
                bottom.add(declineBtn);

                card.add(area, BorderLayout.CENTER);
                card.add(bottom, BorderLayout.SOUTH);
                panel.add(Box.createVerticalStrut(10));
                panel.add(card);
            }
        }

        return container;
    }

    private void updateOverdraftStatus(String username, String timestamp, String newStatus) {
        File inputFile = new File("overdraft_applications.txt");
        File tempFile = new File("overdraft_applications_temp.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(username + "|") && line.contains(timestamp)) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 9) {
                        parts[8] = newStatus;
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < parts.length; i++) {
                            sb.append(parts[i]);
                            if (i < parts.length - 1) sb.append("|");
                        }
                        line = sb.toString();
                    }
                }
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        inputFile.delete();
        tempFile.renameTo(inputFile);
    }

    private JPanel createMortgagePanel() {
        return createApplicationPanel("mortgage_applications.txt", "mortgage_applications_processed.txt");
    }

    private JPanel createApplicationPanel(String inputFile, String processedFile) {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(panel);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        JPanel container = new JPanel(new BorderLayout());
        container.add(scroll, BorderLayout.CENTER);

        List<List<String>> applications = readApplicationsFromFile(inputFile);
        for (List<String> lines : applications) {
            final List<String> appLines = lines;
            final String finalInputFile = inputFile;
            final String finalProcessedFile = processedFile;

            JPanel card = new JPanel();
            card.setLayout(new BorderLayout());
            card.setBackground(Color.WHITE);
            card.setBorder(new EmptyBorder(12, 15, 12, 15));
            card.setMaximumSize(new Dimension(720, 180));

            JTextArea area = new JTextArea();
            area.setEditable(false);
            area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            area.setBackground(Color.WHITE);
            StringBuilder content = new StringBuilder();
            for (String line : appLines) {
                content.append(line).append("\n");
            }
            area.setText(content.toString());

            JButton approveBtn = new JButton("Approve");
            approveBtn.setBackground(new Color(30, 130, 30));
            approveBtn.setForeground(Color.WHITE);
            approveBtn.addActionListener(e -> {
                moveApplicationToProcessed(appLines, finalInputFile, finalProcessedFile);
                if (finalInputFile.equals("loan_applications.txt")) {
                    approveLoanAndTransfer(appLines);
                }
                container.removeAll();
                container.add(createApplicationPanel(finalInputFile, finalProcessedFile), BorderLayout.CENTER);
                container.revalidate();
                container.repaint();
            });

            JButton declineBtn = new JButton("Decline");
            declineBtn.setBackground(new Color(200, 30, 30));
            declineBtn.setForeground(Color.WHITE);
            declineBtn.addActionListener(e -> {
                declineLoan(appLines, finalInputFile, finalProcessedFile);
                container.removeAll();
                container.add(createApplicationPanel(finalInputFile, finalProcessedFile), BorderLayout.CENTER);
                container.revalidate();
                container.repaint();
            });

            JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            bottom.setBackground(Color.WHITE);
            bottom.add(approveBtn);
            bottom.add(declineBtn);

            card.add(area, BorderLayout.CENTER);
            card.add(bottom, BorderLayout.SOUTH);
            panel.add(Box.createVerticalStrut(10));
            panel.add(card);
        }

        return container;
    }

    private void removeLineFromFile(String filePath, String lineToRemove) {
        try {
            File inputFile = new File(filePath);
            File tempFile = new File("temp_" + filePath);
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().equals(lineToRemove.trim())) {
                    writer.write(line);
                    writer.newLine();
                }
            }

            reader.close();
            writer.close();
            inputFile.delete();
            tempFile.renameTo(inputFile);
        } catch (IOException ignored) {}
    }

    private List<List<String>> readApplicationsFromFile(String filePath) {
        List<List<String>> applications = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            List<String> currentApp = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().equals("--------------------------------------------------")) {
                    if (!currentApp.isEmpty()) {
                        applications.add(new ArrayList<>(currentApp));
                        currentApp.clear();
                    }
                } else {
                    currentApp.add(line);
                }
            }
            reader.close();
        } catch (IOException ignored) {}
        return applications;
    }

    private void moveApplicationToProcessed(List<String> application, String inputFile, String processedFile) {
        try {
            File original = new File(inputFile);
            File temp = new File(inputFile + "_temp");
            BufferedReader reader = new BufferedReader(new FileReader(original));
            BufferedWriter writer = new BufferedWriter(new FileWriter(temp));
            BufferedWriter processed = new BufferedWriter(new FileWriter(processedFile, true));

            List<String> currentApp = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().equals("--------------------------------------------------")) {
                    if (currentApp.equals(application)) {
                        for (String l : currentApp) {
                            processed.write(l);
                            processed.newLine();
                        }
                        processed.write("--------------------------------------------------");
                        processed.newLine();
                    } else {
                        for (String l : currentApp) {
                            writer.write(l);
                            writer.newLine();
                        }
                        writer.write("--------------------------------------------------");
                        writer.newLine();
                    }
                    currentApp.clear();
                } else {
                    currentApp.add(line);
                }
            }

            reader.close();
            writer.close();
            processed.close();
            original.delete();
            temp.renameTo(original);

        } catch (IOException ignored) {}
    }

    private void approveLoanAndTransfer(List<String> application) {
        String id = "";
        String user = "";
        String amount = "";
        String type = "";
        String term = "";
        String reason = "";
        for (String line : application) {
            if (line.startsWith("Loan ID:")) id = line.replace("Loan ID:", "").trim();
            if (line.startsWith("User:")) user = line.replace("User:", "").trim();
            if (line.startsWith("Amount:")) amount = line.replace("Amount:", "").replace("£", "").trim();
            if (line.startsWith("Type:")) type = line.replace("Type:", "").trim();
            if (line.startsWith("Term:")) term = line.replace("Term:", "").replace("months", "").trim();
            if (line.startsWith("Reason:")) reason = line.replace("Reason:", "").trim();
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("loan_requests.txt", true))) {
            bw.write(id + ";" + user + ";" + amount + ";" + type + ";" + term + ";" + reason + ";APPROVED");
            bw.newLine();
            UserService userService = new UserService();
            User u = userService.loadUser(user);
            u.setBalance(u.getBalance() + Double.parseDouble(amount));
            userService.saveUser(u);
            if (Dashboard.activeUser != null && Dashboard.activeUser.getUsername().equals(user)) {
                Dashboard.activeUser.setBalance(u.getBalance());
                dashboard.updateBalanceLabel(u.getBalance());
            }
        } catch (Exception ignored) {}
    }

    private void declineLoan(List<String> application, String inputFile, String processedFile) {
        String id = "";
        String user = "";
        String amount = "";
        String type = "";
        String term = "";
        String reason = "";
        for (String line : application) {
            if (line.startsWith("Loan ID:")) id = line.replace("Loan ID:", "").trim();
            if (line.startsWith("User:")) user = line.replace("User:", "").trim();
            if (line.startsWith("Amount:")) amount = line.replace("Amount:", "").replace("£", "").trim();
            if (line.startsWith("Type:")) type = line.replace("Type:", "").trim();
            if (line.startsWith("Term:")) term = line.replace("Term:", "").replace("months", "").trim();
            if (line.startsWith("Reason:")) reason = line.replace("Reason:", "").trim();
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("loan_requests.txt", true))) {
            bw.write(id + ";" + user + ";" + amount + ";" + type + ";" + term + ";" + reason + ";DECLINED");
            bw.newLine();
        } catch (Exception ignored) {}
    }
}
