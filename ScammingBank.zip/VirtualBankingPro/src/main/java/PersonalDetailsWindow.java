package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Properties;

public class PersonalDetailsWindow extends JDialog {
    private JComboBox<String> relationshipCombo;
    private JComboBox<String> nationalityCombo;
    private JTextField niNumberField;

    private static final String FILE_NAME = "personal_details.properties";

    public PersonalDetailsWindow(JFrame parent, String username) {
        super(parent, "Personal details", true);
        setSize(400, 320);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(new Color(24, 28, 44));
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Personal details");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel relationshipPanel = new JPanel(new BorderLayout());
        relationshipPanel.setBackground(new Color(24, 28, 44));
        JLabel relationshipLabel = new JLabel("Relationship");
        relationshipLabel.setForeground(Color.WHITE);
        relationshipCombo = new JComboBox<>(new String[]{"Single", "Married", "Divorced", "Widowed"});
        relationshipPanel.add(relationshipLabel, BorderLayout.NORTH);
        relationshipPanel.add(relationshipCombo, BorderLayout.CENTER);
        relationshipPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 0, 40));

        JPanel nationalityPanel = new JPanel(new BorderLayout());
        nationalityPanel.setBackground(new Color(24, 28, 44));
        JLabel nationalityLabel = new JLabel("Nationality");
        nationalityLabel.setForeground(Color.WHITE);
        nationalityCombo = new JComboBox<>(new String[]{"British", "Romanian", "Polish", "Italian", "Other"});
        nationalityPanel.add(nationalityLabel, BorderLayout.NORTH);
        nationalityPanel.add(nationalityCombo, BorderLayout.CENTER);
        nationalityPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 0, 40));

        JPanel niPanel = new JPanel(new BorderLayout());
        niPanel.setBackground(new Color(24, 28, 44));
        niNumberField = new JTextField();
        JLabel niLabel = new JLabel("National Insurance Number");
        niLabel.setForeground(Color.WHITE);
        niPanel.add(niLabel, BorderLayout.NORTH);
        niPanel.add(niNumberField, BorderLayout.CENTER);
        niPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 0, 40));

        JButton saveButton = new JButton("Save");
        saveButton.setBackground(new Color(0, 120, 215));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveButton.setMaximumSize(new Dimension(150, 35));

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Properties props = new Properties();
                props.setProperty("relationship", relationshipCombo.getSelectedItem().toString());
                props.setProperty("nationality", nationalityCombo.getSelectedItem().toString());
                props.setProperty("niNumber", niNumberField.getText());

                try (FileOutputStream fos = new FileOutputStream(FILE_NAME)) {
                    props.store(fos, "Personal details");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                dispose();
            }
        });

        loadSavedDetails();

        add(Box.createVerticalStrut(10));
        add(titleLabel);
        add(relationshipPanel);
        add(nationalityPanel);
        add(niPanel);
        add(Box.createVerticalStrut(15));
        add(saveButton);
    }

    private void loadSavedDetails() {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(FILE_NAME)) {
            props.load(fis);
            relationshipCombo.setSelectedItem(props.getProperty("relationship", "Single"));
            nationalityCombo.setSelectedItem(props.getProperty("nationality", "British"));
            niNumberField.setText(props.getProperty("niNumber", ""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
