package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ViewEmploymentDetailsWindow extends JDialog {
    private static final String FILE_NAME = "employment_details.properties";

    public ViewEmploymentDetailsWindow(JFrame parent, String username) {
        super(parent, "Employment details", true);
        setSize(400, 280);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(new Color(24, 28, 44));
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Employment details");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(10));
        add(titleLabel);

        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(FILE_NAME)) {
            props.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String employment = props.getProperty("employment", "");
        String address = props.getProperty("address", "");
        String income = props.getProperty("income", "");

        add(Box.createVerticalStrut(15));
        add(createDisplayPanel("Employment", employment));
        add(createDisplayPanel("Address", address));
        add(createDisplayPanel("Income", income));

        JButton editButton = new JButton("Edit");
        editButton.setBackground(new Color(0, 120, 215));
        editButton.setForeground(Color.WHITE);
        editButton.setFocusPainted(false);
        editButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        editButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        editButton.setMaximumSize(new Dimension(150, 35));
        editButton.addActionListener(e -> {
            dispose();
            new EmploymentDetailsWindow(parent, username).setVisible(true);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(24, 28, 44));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        buttonPanel.add(editButton);

        add(Box.createVerticalStrut(10));
        add(buttonPanel);
    }

    private JPanel createDisplayPanel(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(24, 28, 44));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 40, 5, 40));

        JLabel keyLabel = new JLabel(label);
        keyLabel.setForeground(Color.WHITE);
        keyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        panel.add(keyLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        return panel;
    }
}
