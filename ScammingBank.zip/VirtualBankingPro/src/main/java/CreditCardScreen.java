package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.time.LocalDate;
import java.util.stream.IntStream;

public class CreditCardScreen extends JFrame {

    public CreditCardScreen() {
        setTitle("Credit Card Application");
        setSize(600, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color bg = new Color(20, 25, 45);
        Color textColor = Color.WHITE;

        JPanel header = new JPanel();
        header.setBackground(bg);
        JLabel title = new JLabel("Apply for a Credit Card");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(textColor);
        header.add(title);
        add(header, BorderLayout.NORTH);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(bg);
        form.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JTextField nameField = new JTextField();
        nameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JComboBox<String> dayBox = new JComboBox<>(IntStream.rangeClosed(1, 31).mapToObj(String::valueOf).toArray(String[]::new));
        JComboBox<String> monthBox = new JComboBox<>(new String[]{"01","02","03","04","05","06","07","08","09","10","11","12"});
        JComboBox<String> yearBox = new JComboBox<>(IntStream.rangeClosed(1950, LocalDate.now().getYear() - 18).mapToObj(String::valueOf).toArray(String[]::new));
        JPanel dobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        dobPanel.setBackground(bg);
        dobPanel.add(dayBox);
        dobPanel.add(monthBox);
        dobPanel.add(yearBox);

        JTextField incomeField = new JTextField();
        incomeField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JComboBox<String> employmentBox = new JComboBox<>(new String[]{"Employed", "Self-employed", "Student", "Unemployed", "Retired"});
        employmentBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JComboBox<String> yearsBox = new JComboBox<>(IntStream.rangeClosed(0, 50).mapToObj(String::valueOf).toArray(String[]::new));
        JComboBox<String> monthsBox = new JComboBox<>(IntStream.rangeClosed(0, 11).mapToObj(String::valueOf).toArray(String[]::new));
        JPanel jobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        jobPanel.setBackground(bg);
        jobPanel.add(yearsBox);
        jobPanel.add(new JLabel("years"));
        jobPanel.add(monthsBox);
        jobPanel.add(new JLabel("months"));
        for (Component c : jobPanel.getComponents()) {
            if (c instanceof JLabel) {
                ((JLabel) c).setForeground(textColor);
            }
        }

        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        radioPanel.setBackground(bg);
        ButtonGroup group = new ButtonGroup();
        JRadioButton yesBtn = new JRadioButton("Yes");
        JRadioButton noBtn = new JRadioButton("No");
        yesBtn.setBackground(bg);
        yesBtn.setForeground(textColor);
        noBtn.setBackground(bg);
        noBtn.setForeground(textColor);
        group.add(yesBtn);
        group.add(noBtn);
        radioPanel.add(yesBtn);
        radioPanel.add(noBtn);

        JComboBox<String> purposeBox = new JComboBox<>(new String[]{"Shopping", "Emergency", "Debt Consolidation", "Travel"});
        purposeBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JLabel limitLabel = new JLabel("Estimated Credit Limit: £0");
        limitLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        limitLabel.setForeground(new Color(140, 200, 255));
        limitLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton submitBtn = new JButton("Submit Application");
        submitBtn.setBackground(new Color(60, 80, 120));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFocusPainted(false);
        submitBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        submitBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        submitBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String dob = dayBox.getSelectedItem() + "/" + monthBox.getSelectedItem() + "/" + yearBox.getSelectedItem();
            String incomeStr = incomeField.getText().trim();
            String employment = (String) employmentBox.getSelectedItem();
            String years = (String) yearsBox.getSelectedItem();
            String months = (String) monthsBox.getSelectedItem();
            String hasOtherCards = yesBtn.isSelected() ? "Yes" : noBtn.isSelected() ? "No" : "";
            String purpose = (String) purposeBox.getSelectedItem();

            if (name.isEmpty() || incomeStr.isEmpty() || hasOtherCards.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please complete all fields.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double income;
            try {
                income = Double.parseDouble(incomeStr);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Income must be a number.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double limit = 0;
            if (income < 1000) limit = 250;
            else if (income < 2000) limit = 1000;
            else if (income < 3000) limit = 2000;
            else limit = 3500;

            if (employment.equals("Unemployed") || employment.equals("Student")) {
                limit *= 0.6;
            }

            if (hasOtherCards.equals("Yes")) {
                limit *= 0.8;
            }

            limitLabel.setText("Estimated Credit Limit: £" + (int) limit);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("creditcard_applications.txt", true))) {
                writer.write("Name: " + name);
                writer.newLine();
                writer.write("DOB: " + dob);
                writer.newLine();
                writer.write("Monthly Income: £" + incomeStr);
                writer.newLine();
                writer.write("Employment: " + employment);
                writer.newLine();
                writer.write("Time at current job: " + years + "y " + months + "m");
                writer.newLine();
                writer.write("Other credit cards: " + hasOtherCards);
                writer.newLine();
                writer.write("Purpose: " + purpose);
                writer.newLine();
                writer.write("Estimated Credit Limit: £" + (int) limit);
                writer.newLine();
                writer.write("--------------------------------------------------");
                writer.newLine();

                JDialog dialog = new JDialog(this, "Success", true);
                dialog.setSize(350, 160);
                dialog.setLocationRelativeTo(this);
                dialog.setLayout(new BorderLayout());
                dialog.setUndecorated(true);

                Color successBg = new Color(25, 30, 45);
                JPanel panel = new JPanel();
                panel.setBackground(successBg);
                panel.setBorder(BorderFactory.createLineBorder(new Color(70, 120, 180), 2));
                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

                JLabel msg = new JLabel("Application submitted successfully!", SwingConstants.CENTER);
                msg.setFont(new Font("Segoe UI", Font.BOLD, 16));
                msg.setForeground(Color.WHITE);
                msg.setAlignmentX(Component.CENTER_ALIGNMENT);
                msg.setBorder(BorderFactory.createEmptyBorder(30, 10, 10, 10));

                JButton okButton = new JButton("OK");
                okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
                okButton.setFocusPainted(false);
                okButton.setBackground(new Color(70, 120, 180));
                okButton.setForeground(Color.WHITE);
                okButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
                okButton.setPreferredSize(new Dimension(80, 35));
                okButton.addActionListener(ev -> dialog.dispose());

                panel.add(msg);
                panel.add(Box.createVerticalStrut(15));
                panel.add(okButton);

                dialog.add(panel, BorderLayout.CENTER);
                dialog.setVisible(true);

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving application.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        addFormRow(form, "Full Name:", nameField, textColor);
        addFormRow(form, "Date of Birth:", dobPanel, textColor);
        addFormRow(form, "Monthly Income (£):", incomeField, textColor);
        addFormRow(form, "Employment Status:", employmentBox, textColor);
        addFormRow(form, "Years at Current Job:", jobPanel, textColor);
        addFormRow(form, "Do you have other credit cards?", radioPanel, textColor);
        addFormRow(form, "Purpose of Credit Card:", purposeBox, textColor);
        form.add(Box.createVerticalStrut(20));
        form.add(limitLabel);
        form.add(Box.createVerticalStrut(20));
        form.add(submitBtn);

        JScrollPane scrollPane = new JScrollPane(form);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    private void addFormRow(JPanel form, String labelText, JComponent input, Color color) {
        JLabel label = new JLabel(labelText);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setForeground(color);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        form.add(label);
        form.add(Box.createVerticalStrut(5));
        form.add(input);
        form.add(Box.createVerticalStrut(15));
    }
}
