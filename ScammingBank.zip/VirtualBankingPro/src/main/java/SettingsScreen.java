package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class SettingsScreen extends JFrame {
    private User currentUser;
    private LanguageManager langManager;

    private JLabel titleLabel;
    private JLabel passwordLabel;
    private JPasswordField oldPassword;
    private JPasswordField newPassword;
    private JButton changePasswordBtn;

    private JLabel languageLabel;
    private JComboBox<String> languageBox;

    private JLabel modeLabel;
    private JCheckBox darkModeBox;

    private JButton exportBtn;
    private JButton deleteBtn;

    private JLabel supportLabel;
    private JButton closeBtn;

    private JLabel versionLabel;

    public SettingsScreen(User user) {
        this.currentUser = user;
        this.langManager = new LanguageManager();

        setTitle("Settings");
        setSize(600, 510);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
        loadLanguage(currentUser.getLanguage());
        applyTheme(currentUser.isDarkMode());
        darkModeBox.setSelected(currentUser.isDarkMode());

        setVisible(true);
    }

    private void initComponents() {
        titleLabel = new JLabel("Settings");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 20, 600, 35);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        passwordLabel = new JLabel("Change Password:");
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordLabel.setBounds(80, 90, 150, 25);
        add(passwordLabel);

        oldPassword = new JPasswordField();
        oldPassword.setBounds(240, 90, 260, 25);
        add(oldPassword);

        newPassword = new JPasswordField();
        newPassword.setBounds(240, 120, 260, 25);
        add(newPassword);

        changePasswordBtn = new JButton("Update Password");
        changePasswordBtn.setBounds(240, 155, 180, 30);
        changePasswordBtn.setBackground(new Color(30, 144, 255));
        changePasswordBtn.setForeground(Color.WHITE);
        changePasswordBtn.setFocusPainted(false);
        changePasswordBtn.addActionListener(e -> changePassword());
        add(changePasswordBtn);

        languageLabel = new JLabel("Language:");
        languageLabel.setForeground(Color.WHITE);
        languageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        languageLabel.setBounds(80, 210, 150, 25);
        add(languageLabel);

        String[] languages = {"English", "Romanian", "Spanish", "French", "German", "Italian", "Japanese", "Chinese", "Russian", "Portuguese"};
        languageBox = new JComboBox<>(languages);
        languageBox.setBounds(240, 210, 260, 25);
        languageBox.addActionListener(e -> changeLanguage());
        add(languageBox);

        modeLabel = new JLabel("Dark Mode:");
        modeLabel.setForeground(Color.WHITE);
        modeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        modeLabel.setBounds(80, 250, 150, 25);
        add(modeLabel);

        darkModeBox = new JCheckBox();
        darkModeBox.setBounds(240, 250, 25, 25);
        darkModeBox.addActionListener(e -> toggleDarkMode());
        add(darkModeBox);

        exportBtn = new JButton("Export Transaction History");
        exportBtn.setBounds(190, 300, 220, 35);
        exportBtn.setBackground(new Color(100, 100, 255));
        exportBtn.setForeground(Color.WHITE);
        exportBtn.setFocusPainted(false);
        exportBtn.addActionListener(e -> exportHistory());
        add(exportBtn);

        deleteBtn = new JButton("Delete Account");
        deleteBtn.setBackground(new Color(200, 30, 30));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setBounds(220, 350, 160, 35);
        deleteBtn.setFocusPainted(false);
        deleteBtn.addActionListener(e -> deleteAccount());
        add(deleteBtn);

        closeBtn = new JButton("Close");
        closeBtn.setBounds(240, 395, 120, 35);
        closeBtn.setBackground(new Color(0, 120, 215));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFocusPainted(false);
        closeBtn.addActionListener(e -> dispose());
        add(closeBtn);

        versionLabel = new JLabel("ScammingBank v1.0");
        versionLabel.setForeground(Color.WHITE);
        versionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        versionLabel.setBounds(20, 440, 200, 25);
        add(versionLabel);

        supportLabel = new JLabel("Support: support@scammingbank.co.uk");
        supportLabel.setForeground(Color.WHITE);
        supportLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        supportLabel.setBounds(350, 440, 230, 25);
        supportLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        add(supportLabel);
    }

    private void loadLanguage(String lang) {
        langManager.loadLanguage(lang);
        languageBox.setSelectedItem(lang);
        titleLabel.setText("Settings");
        passwordLabel.setText("Change Password:");
        changePasswordBtn.setText("Update Password");
        languageLabel.setText("Language:");
        modeLabel.setText("Dark Mode:");
        exportBtn.setText("Export Transaction History");
        deleteBtn.setText("Delete Account");
        supportLabel.setText("Support: support@scammingbank.co.uk");
        versionLabel.setText("ScammingBank v1.0");
        closeBtn.setText("Close");
    }

    private void applyTheme(boolean dark) {
        Color bg = dark ? new Color(15, 15, 15) : Color.WHITE;
        Color fg = dark ? Color.WHITE : Color.BLACK;

        getContentPane().setBackground(bg);
        titleLabel.setForeground(fg);
        passwordLabel.setForeground(fg);
        languageLabel.setForeground(fg);
        modeLabel.setForeground(fg);
        supportLabel.setForeground(fg);
        versionLabel.setForeground(fg);

        darkModeBox.setBackground(bg);
        darkModeBox.setForeground(fg);
        languageBox.setBackground(bg);
        languageBox.setForeground(fg);
    }

    private void changePassword() {
        String oldPass = new String(oldPassword.getPassword()).trim();
        String newPass = new String(newPassword.getPassword()).trim();
        if (!oldPass.equals(currentUser.getPassword())) {
            JOptionPane.showMessageDialog(this, langManager.get("password_incorrect"), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (newPass.length() < 4) {
            JOptionPane.showMessageDialog(this, langManager.get("password_short"), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        currentUser.setPassword(newPass);
        new UserService().saveUser(currentUser);
        JOptionPane.showMessageDialog(this, langManager.get("password_changed"));
        oldPassword.setText("");
        newPassword.setText("");
    }

    private void changeLanguage() {
        String selected = (String) languageBox.getSelectedItem();
        currentUser.setLanguage(selected);
        new UserService().saveUser(currentUser);
        langManager.loadLanguage(langManager.getLangCodeByName(selected));
        loadLanguage(selected);
    }

    private void toggleDarkMode() {
        boolean dark = darkModeBox.isSelected();
        currentUser.setDarkMode(dark);
        new UserService().saveUser(currentUser);
        applyTheme(dark);
    }

    private void exportHistory() {
        String username = currentUser.getUsername();
        File input = new File("transactions_" + username + ".txt");
        File output = new File(username + "_exported_history.txt");

        if (!input.exists()) {
            showBankDialog("No transaction history found for this account.", "Export Failed");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(input));
             BufferedWriter writer = new BufferedWriter(new FileWriter(output))) {
            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }
            showBankDialog("Your transaction history has been securely exported.\n\nSaved as: " + output.getName() + "\nLocation: Application directory\n\nThank you for using ScammingBank.", "Export Completed");
        } catch (IOException ex) {
            showBankDialog("Failed to export transaction history.", "Export Failed");
            ex.printStackTrace();
        }
    }

    private void deleteAccount() {
        if (currentUser.getBalance() >= 10) {
            JOptionPane.showMessageDialog(this, langManager.get("delete_error_balance"), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, langManager.get("delete_confirm"), "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            new UserService().deleteUser(currentUser.getUsername());
            JOptionPane.showMessageDialog(this, langManager.get("delete_success"));
            dispose();
            new LoginScreen().setVisible(true);
        }
    }

    private void showBankDialog(String message, String title) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(400, 250);
        dialog.setLocationRelativeTo(this);
        dialog.setUndecorated(true);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(30, 35, 50));
        panel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 10, 0, 10));

        JTextArea msgArea = new JTextArea(message);
        msgArea.setWrapStyleWord(true);
        msgArea.setLineWrap(true);
        msgArea.setEditable(false);
        msgArea.setFocusable(false);
        msgArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        msgArea.setForeground(Color.WHITE);
        msgArea.setBackground(new Color(30, 35, 50));
        msgArea.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JButton okButton = new JButton("OK");
        okButton.setFocusPainted(false);
        okButton.setBackground(new Color(40, 90, 160));
        okButton.setForeground(Color.WHITE);
        okButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        okButton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        okButton.addActionListener(e -> dialog.dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(30, 35, 50));
        buttonPanel.add(okButton);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(msgArea, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(panel);
        dialog.setVisible(true);
    }
}
