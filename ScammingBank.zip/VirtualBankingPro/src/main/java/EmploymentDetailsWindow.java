package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Properties;

public class EmploymentDetailsWindow extends JDialog {
    private JComboBox<String> employmentCombo;
    private JTextField addressField;
    private JTextField incomeField;

    private static final String FILE_NAME = "employment_details.properties";

    public EmploymentDetailsWindow(JFrame parent, String username) {
        super(parent, "Edit employment details", true);
        setSize(400, 320);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(new Color(24, 28, 44));
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Edit employment details");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        employmentCombo = new JComboBox<>(new String[]{"Full-time", "Part-time", "Self-employed", "Unemployed", "Student"});
        addressField = new JTextField();
        incomeField = new JTextField();

        add(Box.createVerticalStrut(10));
        add(titleLabel);
        add(createComboPanel("Employment", employmentCombo));
        add(createInputPanel("Address", addressField));
        add(createInputPanel("Income", incomeField));

        JButton saveButton = new JButton("Save");
        saveButton.setBackground(new Color(0, 120, 215));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveButton.setMaximumSize(new Dimension(150, 35));
        saveButton.addActionListener(e -> {
            Properties props = new Properties();
            props.setProperty("employment", employmentCombo.getSelectedItem().toString());
            props.setProperty("address", addressField.getText());
            props.setProperty("income", incomeField.getText());

            try (FileOutputStream fos = new FileOutputStream(FILE_NAME)) {
                props.store(fos, "Employment details");
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            dispose();
        });

        loadSavedDetails();
        add(Box.createVerticalStrut(15));
        add(saveButton);
    }

    private JPanel createInputPanel(String label, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(24, 28, 44));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 40, 0, 40));

        JLabel jLabel = new JLabel(label);
        jLabel.setForeground(Color.WHITE);
        panel.add(jLabel, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createComboPanel(String label, JComboBox<String> comboBox) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(24, 28, 44));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 40, 0, 40));

        JLabel jLabel = new JLabel(label);
        jLabel.setForeground(Color.WHITE);
        panel.add(jLabel, BorderLayout.NORTH);
        panel.add(comboBox, BorderLayout.CENTER);
        return panel;
    }

    private void loadSavedDetails() {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(FILE_NAME)) {
            props.load(fis);
            employmentCombo.setSelectedItem(props.getProperty("employment", "Full-time"));
            addressField.setText(props.getProperty("address", ""));
            incomeField.setText(props.getProperty("income", ""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
