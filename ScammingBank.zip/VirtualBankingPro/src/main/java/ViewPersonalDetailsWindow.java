package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ViewPersonalDetailsWindow extends JDialog {
    private static final String FILE_NAME = "personal_details.properties";

    public ViewPersonalDetailsWindow(JFrame parent, String username) {
        super(parent, "Personal details", true);
        setSize(400, 280);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(new Color(24, 28, 44));
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Personal details");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(10));
        add(titleLabel);

        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(FILE_NAME)) {
            props.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String relationship = props.getProperty("relationship", "Single");
        String nationality = props.getProperty("nationality", "British");
        String niNumber = props.getProperty("niNumber", "");

        add(Box.createVerticalStrut(15));
        add(createDisplayPanel("Relationship", relationship));
        add(createDisplayPanel("Nationality", nationality));
        add(createDisplayPanel("National Insurance Number", niNumber));

        JButton editButton = new JButton("Edit");
        editButton.setBackground(new Color(0, 120, 215));
        editButton.setForeground(Color.WHITE);
        editButton.setFocusPainted(false);
        editButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        editButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        editButton.setMaximumSize(new Dimension(150, 35));
        editButton.addActionListener(e -> {
            dispose();
            new PersonalDetailsWindow(parent, username).setVisible(true);
        });

        add(Box.createVerticalStrut(15));
        add(editButton);
    }

    private JPanel createDisplayPanel(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(24, 28, 44));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 40, 5, 40));

        JLabel keyLabel = new JLabel(label);
        keyLabel.setForeground(Color.WHITE);
        keyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        panel.add(keyLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);
        return panel;
    }
}
