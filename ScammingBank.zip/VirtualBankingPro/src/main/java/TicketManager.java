package com.virtualbank;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TicketManager {

    private static final String TICKETS_FILE = "tickets.txt";
    private static final String TICKETS_RESOLVED_FILE = "tickets_resolved.txt";

    public static synchronized void addTicket(String username, String message) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TICKETS_FILE, true))) {
            writer.write(username + ": " + message);
            writer.newLine();
        }
    }

    public static synchronized List<String> loadTickets(boolean resolved) throws IOException {
        String filePath = resolved ? TICKETS_RESOLVED_FILE : TICKETS_FILE;
        List<String> tickets = new ArrayList<>();
        File file = new File(filePath);
        if (!file.exists()) file.createNewFile();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tickets.add(line);
            }
        }
        return tickets;
    }

    public static synchronized void moveToResolved(String ticketLine) throws IOException {
        List<String> activeTickets = new ArrayList<>();
        List<String> resolvedTickets = loadTickets(true);

        try (BufferedReader reader = new BufferedReader(new FileReader(TICKETS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().equals(ticketLine.trim())) {
                    resolvedTickets.add(line);
                } else {
                    activeTickets.add(line);
                }
            }
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TICKETS_FILE))) {
            for (String t : activeTickets) {
                writer.write(t);
                writer.newLine();
            }
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TICKETS_RESOLVED_FILE))) {
            for (String t : resolvedTickets) {
                writer.write(t);
                writer.newLine();
            }
        }
    }
}
