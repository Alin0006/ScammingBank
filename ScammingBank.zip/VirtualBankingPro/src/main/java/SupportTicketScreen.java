package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class SupportTicketScreen extends JFrame {

    public SupportTicketScreen(String username) {
        setTitle("Contact Support");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(30, 60, 90));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Submit a Support Ticket");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextArea messageArea = new JTextArea(10, 30);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(messageArea);
        scrollPane.setMaximumSize(new Dimension(400, 200));

        JButton sendButton = new JButton("Send Ticket");
        sendButton.setBackground(Color.BLACK);
        sendButton.setForeground(Color.WHITE);
        sendButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        sendButton.setMaximumSize(new Dimension(200, 35));

        sendButton.addActionListener(e -> {
            String message = messageArea.getText().trim();
            if (message.isEmpty()) {
                showDialog("Error", "Please enter a message.", Color.RED);
                return;
            }
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\ProiecteJava\\VirtualBankingPro\\tickets.txt", true));
                writer.write(username + ": " + message);
                writer.newLine();
                writer.close();
                showDialog("Ticket Sent", "Your ticket has been submitted to support.", new Color(30, 60, 90));
                dispose();
            } catch (IOException ex) {
                showDialog("Error", "Failed to send ticket.", Color.RED);
            }
        });

        panel.add(Box.createVerticalStrut(20));
        panel.add(title);
        panel.add(Box.createVerticalStrut(20));
        panel.add(scrollPane);
        panel.add(Box.createVerticalStrut(20));
        panel.add(sendButton);
        panel.add(Box.createVerticalStrut(20));

        add(panel);
        setVisible(true);
    }

    private void showDialog(String title, String message, Color background) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(400, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(background);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel label = new JLabel(message);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton okButton = new JButton("OK");
        okButton.setBackground(Color.BLACK);
        okButton.setForeground(Color.WHITE);
        okButton.setFocusPainted(false);
        okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        okButton.setMaximumSize(new Dimension(200, 35));
        okButton.addActionListener(e -> dialog.dispose());

        panel.add(Box.createVerticalStrut(25));
        panel.add(label);
        panel.add(Box.createVerticalStrut(20));
        panel.add(okButton);
        panel.add(Box.createVerticalStrut(15));

        dialog.add(panel);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }
}
