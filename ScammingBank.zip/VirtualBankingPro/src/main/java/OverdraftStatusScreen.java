package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class OverdraftStatusScreen extends JFrame {
    private String currentUser;

    public OverdraftStatusScreen(String username) {
        this.currentUser = username;
        setTitle("Overdraft Status");
        setSize(500, 430);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(15, 15, 15));

        JLabel titleLabel = new JLabel("Your Overdraft Status");
        titleLabel.setBounds(130, 20, 300, 30);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        JTextArea statusArea = new JTextArea();
        statusArea.setEditable(false);
        statusArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        statusArea.setForeground(Color.GREEN);
        statusArea.setBackground(new Color(15, 15, 15));
        statusArea.setBorder(BorderFactory.createLineBorder(Color.CYAN));

        JScrollPane scrollPane = new JScrollPane(statusArea);
        scrollPane.setBounds(40, 70, 400, 250);
        add(scrollPane);

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(190, 340, 100, 30);
        closeButton.setBackground(new Color(0, 120, 215));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        add(closeButton);

        closeButton.addActionListener(e -> dispose());

        String data = loadOverdraftData(currentUser);
        if (data == null) {
            data = loadProcessedOverdraftData(currentUser);
        }

        if (data == null) {
            statusArea.setText("No overdraft application found.");
        } else {
            String[] parts = data.split("\\|");
            if (parts.length >= 9) {
                StringBuilder sb = new StringBuilder();
                sb.append("Overdraft Amount: ").append(parts[1]).append("\n");
                sb.append("Reason: ").append(parts[2]).append("\n");
                sb.append("Employer: ").append(parts[3]).append("\n");
                sb.append("Income: ").append(parts[4]).append("\n");
                sb.append("Expenses: ").append(parts[5]).append("\n");
                sb.append("Purpose: ").append(parts[6]).append("\n");
                sb.append("Applied: ").append(parts[7]).append("\n");
                sb.append("Status: ").append(parts[8]).append("\n");
                statusArea.setText(sb.toString());
            } else {
                statusArea.setText("Incomplete application data.");
            }
        }

        setVisible(true);
    }

    private String loadOverdraftData(String user) {
        File file = new File("overdraft_applications.txt");
        if (!file.exists()) return null;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            String lastMatch = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(user + "|")) {
                    lastMatch = line;
                }
            }
            return lastMatch;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private String loadProcessedOverdraftData(String user) {
        File file = new File("overdraft_applications_processed.txt");
        if (!file.exists()) return null;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            String lastMatch = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(user + "|")) {
                    lastMatch = line;
                }
            }
            return lastMatch;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
