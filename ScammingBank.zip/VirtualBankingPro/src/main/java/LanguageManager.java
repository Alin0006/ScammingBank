package com.virtualbank;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class LanguageManager {
    private Properties translations = new Properties();
    private String currentLang = "English";
    private static final Map<String, String> langNameToCode = new HashMap<>();

    static {
        langNameToCode.put("English", "en");
        langNameToCode.put("Romanian", "ro");
        langNameToCode.put("Spanish", "es");
        langNameToCode.put("French", "fr");
        langNameToCode.put("German", "de");
        langNameToCode.put("Italian", "it");
        langNameToCode.put("Japanese", "ja");
        langNameToCode.put("Chinese", "zh");
        langNameToCode.put("Russian", "ru");
        langNameToCode.put("Portuguese", "pt");
    }

    public LanguageManager() {
        loadLanguage("en");
    }

    public void loadLanguage(String langCodeOrName) {
        String langCode = langCodeOrName;
        if (langCodeOrName.length() > 2) {
            langCode = langNameToCode.getOrDefault(langCodeOrName, "en");
        }
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("lang/lang_" + langCode + ".properties")) {
            translations.clear();
            if (input != null) {
                translations.load(input);
                currentLang = getLangNameByCode(langCode);
            } else {
                System.err.println("Language file for '" + langCode + "' not found, defaulting to English.");
                if (!langCode.equals("en")) {
                    loadEnglishFallback();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadEnglishFallback() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("lang/lang_en.properties")) {
            translations.clear();
            if (input != null) {
                translations.load(input);
                currentLang = "English";
            } else {
                System.err.println("English language file not found.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String get(String key) {
        return translations.getProperty(key, key);
    }

    public String getCurrentLang() {
        return currentLang;
    }

    public String getCurrentLangName(String codeOrName) {
        if (codeOrName.length() == 2) {
            return getLangNameByCode(codeOrName);
        }
        return codeOrName;
    }

    public String getLangNameByCode(String code) {
        for (Map.Entry<String, String> entry : langNameToCode.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(code)) {
                return entry.getKey();
            }
        }
        return "English";
    }

    public String getLangCodeByName(String name) {
        return langNameToCode.getOrDefault(name, "en");
    }
}
