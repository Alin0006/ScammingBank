package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class AboutMeScreen extends JDialog {

    public AboutMeScreen(JFrame parent, String username) {
        super(parent, "About me", true);
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        Color bg = new Color(30, 35, 50);
        Color panelColor = new Color(40, 45, 60);
        Color textColor = Color.WHITE;

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(bg);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel title = new JLabel("About me");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(title);
        mainPanel.add(Box.createVerticalStrut(20));

        mainPanel.add(createInfoButton("Personal details", "Relationship, nationality and National Insurance number", () -> {
            new ViewPersonalDetailsWindow(parent, username).setVisible(true);
        }, panelColor, textColor));

        mainPanel.add(Box.createVerticalStrut(15));

        mainPanel.add(createInfoButton("Contact details", "Phone, Email and Address", () -> {
            new ViewContactDetailsWindow(parent, username).setVisible(true);
        }, panelColor, textColor));

        mainPanel.add(Box.createVerticalStrut(15));

        mainPanel.add(createInfoButton("Employment details", "Employment, Address, Income", () -> {
            new ViewEmploymentDetailsWindow(parent, username).setVisible(true);
        }, panelColor, textColor));

        add(mainPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private JPanel createInfoButton(String title, String subtitle, Runnable onClick, Color bg, Color fg) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(bg);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                onClick.run();
            }
        });

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(fg);

        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(fg);

        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(subtitleLabel);

        return panel;
    }
}
