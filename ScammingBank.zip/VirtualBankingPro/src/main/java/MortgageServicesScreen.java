package screens;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MortgageServicesScreen extends JFrame {
    private JTextField propertyValueField;
    private JTextField depositField;
    private JComboBox<String> termBox;
    private JComboBox<String> employmentBox;
    private JTextField incomeField;
    private JTextField expensesField;
    private JComboBox<String> purposeBox;
    private JLabel estimatedLabel;
    private String currentUser;

    public MortgageServicesScreen(String username) {
        this.currentUser = username;
        setTitle("Mortgage Application");
        setSize(500, 660);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(20, 20, 20));

        JLabel titleLabel = new JLabel("Apply for a Mortgage");
        titleLabel.setBounds(130, 20, 300, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        JTextArea infoLabel = new JTextArea("Fixed 2.5% interest for the first 2 years. Reverting to a variable rate of 5% + inflation thereafter.");
        infoLabel.setBounds(30, 55, 440, 35);
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        infoLabel.setForeground(Color.LIGHT_GRAY);
        infoLabel.setBackground(new Color(20, 20, 20));
        infoLabel.setWrapStyleWord(true);
        infoLabel.setLineWrap(true);
        infoLabel.setEditable(false);
        infoLabel.setFocusable(false);
        infoLabel.setHighlighter(null);
        add(infoLabel);

        JLabel propertyValueLabel = new JLabel("Property Value (£):");
        propertyValueLabel.setBounds(50, 100, 150, 25);
        propertyValueLabel.setForeground(Color.WHITE);
        add(propertyValueLabel);

        propertyValueField = new JTextField();
        propertyValueField.setBounds(220, 100, 200, 25);
        add(propertyValueField);

        JLabel depositLabel = new JLabel("Deposit Amount (£):");
        depositLabel.setBounds(50, 140, 150, 25);
        depositLabel.setForeground(Color.WHITE);
        add(depositLabel);

        depositField = new JTextField();
        depositField.setBounds(220, 140, 200, 25);
        add(depositField);

        JLabel termLabel = new JLabel("Mortgage Term (years):");
        termLabel.setBounds(50, 180, 170, 25);
        termLabel.setForeground(Color.WHITE);
        add(termLabel);

        String[] terms = {"5", "10", "15", "20", "25", "30"};
        termBox = new JComboBox<>(terms);
        termBox.setBounds(220, 180, 200, 25);
        add(termBox);

        JLabel employmentLabel = new JLabel("Employment Status:");
        employmentLabel.setBounds(50, 220, 150, 25);
        employmentLabel.setForeground(Color.WHITE);
        add(employmentLabel);

        String[] employment = {"Employed", "Self-Employed", "Unemployed", "Retired", "Student"};
        employmentBox = new JComboBox<>(employment);
        employmentBox.setBounds(220, 220, 200, 25);
        add(employmentBox);

        JLabel incomeLabel = new JLabel("Annual Income (£):");
        incomeLabel.setBounds(50, 260, 150, 25);
        incomeLabel.setForeground(Color.WHITE);
        add(incomeLabel);

        incomeField = new JTextField();
        incomeField.setBounds(220, 260, 200, 25);
        add(incomeField);

        JLabel expensesLabel = new JLabel("Monthly Expenses (£):");
        expensesLabel.setBounds(50, 300, 170, 25);
        expensesLabel.setForeground(Color.WHITE);
        add(expensesLabel);

        expensesField = new JTextField();
        expensesField.setBounds(220, 300, 200, 25);
        add(expensesField);

        JLabel purposeLabel = new JLabel("Purpose of Property:");
        purposeLabel.setBounds(50, 340, 150, 25);
        purposeLabel.setForeground(Color.WHITE);
        add(purposeLabel);

        String[] purpose = {"Buy to live", "Buy to let"};
        purposeBox = new JComboBox<>(purpose);
        purposeBox.setBounds(220, 340, 200, 25);
        add(purposeBox);

        estimatedLabel = new JLabel("");
        estimatedLabel.setBounds(50, 380, 400, 25);
        estimatedLabel.setForeground(Color.GREEN);
        estimatedLabel.setFont(new Font("Arial", Font.BOLD, 14));
        estimatedLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(estimatedLabel);

        JButton applyButton = new JButton("Submit Application");
        applyButton.setBounds(150, 440, 200, 40);
        applyButton.setBackground(new Color(0, 120, 255));
        applyButton.setForeground(Color.WHITE);
        applyButton.setFocusPainted(false);
        add(applyButton);

        propertyValueField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateDepositAndEstimate(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateDepositAndEstimate(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateDepositAndEstimate(); }
        });

        depositField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateEstimateOnly(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateEstimateOnly(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateEstimateOnly(); }
        });

        termBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateEstimateOnly();
            }
        });

        applyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String propertyValue = propertyValueField.getText();
                String deposit = depositField.getText();
                String term = (String) termBox.getSelectedItem();
                String employment = (String) employmentBox.getSelectedItem();
                String income = incomeField.getText();
                String expenses = expensesField.getText();
                String purpose = (String) purposeBox.getSelectedItem();

                if (propertyValue.isEmpty() || deposit.isEmpty() || income.isEmpty() || expenses.isEmpty()) return;

                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
                String timestamp = dtf.format(LocalDateTime.now());

                String entry = currentUser + "|" + propertyValue + "|" + deposit + "|" + term + "|" + employment + "|" + income + "|" + expenses + "|" + purpose + "|" + timestamp + "|" + "PENDING";

                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter("mortgage_applications.txt", true));
                    writer.write(entry);
                    writer.newLine();
                    writer.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                JDialog dialog = new JDialog();
                dialog.setSize(400, 200);
                dialog.setLocationRelativeTo(null);
                dialog.setLayout(null);
                dialog.getContentPane().setBackground(new Color(30, 30, 30));

                JLabel message = new JLabel("Mortgage application submitted successfully!", SwingConstants.CENTER);
                message.setBounds(20, 50, 360, 30);
                message.setForeground(Color.WHITE);
                message.setFont(new Font("Arial", Font.BOLD, 14));
                dialog.add(message);

                JButton close = new JButton("Close");
                close.setBounds(150, 100, 100, 30);
                close.setBackground(new Color(0, 120, 255));
                close.setForeground(Color.WHITE);
                dialog.add(close);

                close.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();
                        dispose();
                    }
                });

                dialog.setVisible(true);
            }
        });

        setVisible(true);
    }

    private void updateDepositAndEstimate() {
        SwingUtilities.invokeLater(() -> {
            try {
                String raw = propertyValueField.getText().replaceAll("[^0-9]", "");
                if (!raw.isEmpty()) {
                    double value = Double.parseDouble(raw);
                    int deposit = (int) (value * 0.10);
                    depositField.setText(String.valueOf(deposit));
                } else {
                    depositField.setText("");
                }
            } catch (Exception ex) {
                depositField.setText("");
            }
            updateEstimateOnly();
        });
    }

    private void updateEstimateOnly() {
        SwingUtilities.invokeLater(() -> {
            try {
                String rawProp = propertyValueField.getText().replaceAll("[^0-9]", "");
                String rawDep = depositField.getText().replaceAll("[^0-9]", "");
                if (!rawProp.isEmpty() && !rawDep.isEmpty()) {
                    double property = Double.parseDouble(rawProp);
                    double deposit = Double.parseDouble(rawDep);
                    double principal = property - deposit;
                    int years = Integer.parseInt((String) termBox.getSelectedItem());
                    int months = years * 12;
                    double monthlyRate = 0.025 / 12;
                    double monthly = (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -months));
                    estimatedLabel.setText("Estimated monthly payment (first 2 years): £" + String.format("%.0f", monthly));
                } else {
                    estimatedLabel.setText("");
                }
            } catch (Exception ex) {
                estimatedLabel.setText("");
            }
        });
    }
}


