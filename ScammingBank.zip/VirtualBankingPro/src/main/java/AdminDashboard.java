package com.virtualbank;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

public class AdminDashboard extends JFrame {

    private JTextField userField;
    private JTextField amountField;
    private JTextField searchField;
    private JPanel usersPanel;
    private JScrollPane scrollPane;

    public AdminDashboard() {
        setTitle("Admin Panel - Manage Accounts");
        setSize(750, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(230, 235, 245));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel();
        logo.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        logo.setOpaque(false);
        logo.setVisible(false);

        Timer fadeInTimer = new Timer(20, null);
        fadeInTimer.addActionListener(new ActionListener() {
            float alpha = 0f;
            public void actionPerformed(ActionEvent e) {
                alpha += 0.05f;
                logo.setVisible(true);
                logo.repaint();
                if (alpha >= 1f) {
                    fadeInTimer.stop();
                }
            }
        });
        fadeInTimer.start();

        JLabel title = new JLabel("Add Funds to Existing Account");
        title.setForeground(new Color(20, 20, 20));
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        userField = new JTextField("Enter username");
        userField.setMaximumSize(new Dimension(300, 35));
        userField.setAlignmentX(Component.CENTER_ALIGNMENT);

        amountField = new JTextField("Enter amount");
        amountField.setMaximumSize(new Dimension(300, 35));
        amountField.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton addButton = new JButton("Add Funds");
        addButton.setBackground(Color.BLACK);
        addButton.setForeground(Color.WHITE);
        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addButton.setMaximumSize(new Dimension(300, 40));

        addButton.addActionListener(e -> {
            String username = userField.getText().trim();
            String amountText = amountField.getText().trim();
            if (username.isEmpty() || amountText.isEmpty()) {
                showMessage("Please enter both username and amount.");
                return;
            }
            try {
                double amount = Double.parseDouble(amountText);
                UserService service = new UserService();
                boolean success = service.updateBalance(username, amount);
                showMessage(success ? "Funds added successfully." : "User not found.");
                refreshUserList(searchField.getText().trim());
            } catch (NumberFormatException ex) {
                showMessage("Invalid amount.");
            }
        });

        searchField = new JTextField("Search user...");
        searchField.setMaximumSize(new Dimension(300, 35));
        searchField.setAlignmentX(Component.CENTER_ALIGNMENT);
        searchField.setForeground(Color.GRAY);

        searchField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (searchField.getText().equals("Search user...")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText("Search user...");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                refreshUserList(searchField.getText().trim());
            }
            public void removeUpdate(DocumentEvent e) {
                refreshUserList(searchField.getText().trim());
            }
            public void changedUpdate(DocumentEvent e) {
                refreshUserList(searchField.getText().trim());
            }
        });

        JButton ticketsButton = new JButton("View Support Tickets");
        ticketsButton.setBackground(new Color(50, 50, 120));
        ticketsButton.setForeground(Color.WHITE);
        ticketsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        ticketsButton.setMaximumSize(new Dimension(300, 35));
        ticketsButton.addActionListener(e -> openTicketViewer());

        JButton refreshBtn = new JButton(new ImageIcon(getClass().getResource("/icons/refresh_icon.png")));
        refreshBtn.setContentAreaFilled(false);
        refreshBtn.setBorderPainted(false);
        refreshBtn.setFocusPainted(false);
        refreshBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        refreshBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        refreshBtn.setMaximumSize(new Dimension(40, 40));
        refreshBtn.addActionListener(e -> {
            new Thread(() -> {
                for (int i = 0; i <= 360; i += 15) {
                    final int angle = i;
                    SwingUtilities.invokeLater(() -> {
                        try {
                            ImageIcon icon = new ImageIcon(getClass().getResource("/icons/refresh_icon.png"));
                            Image image = icon.getImage();
                            int w = image.getWidth(null);
                            int h = image.getHeight(null);
                            BufferedImage rotated = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                            Graphics2D g2 = rotated.createGraphics();
                            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                            g2.rotate(Math.toRadians(angle), w / 2.0, h / 2.0);
                            g2.drawImage(image, 0, 0, null);
                            g2.dispose();
                            refreshBtn.setIcon(new ImageIcon(rotated));
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    });
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
                SwingUtilities.invokeLater(() -> {
                    refreshBtn.setIcon(new ImageIcon(getClass().getResource("/icons/refresh_icon.png")));
                    refreshUserList("");
                });
            }).start();
        });

        JButton logoutButton = new JButton("Log Out");
        logoutButton.setBackground(new Color(50, 50, 50));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutButton.setMaximumSize(new Dimension(300, 35));
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginScreen().setVisible(true);
        });

        usersPanel = new JPanel();
        usersPanel.setLayout(new BoxLayout(usersPanel, BoxLayout.Y_AXIS));
        usersPanel.setBackground(new Color(240, 240, 240));

        scrollPane = new JScrollPane(usersPanel);
        scrollPane.setPreferredSize(new Dimension(680, 420));
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        panel.add(Box.createVerticalStrut(15));
        panel.add(logo);
        panel.add(Box.createVerticalStrut(15));
        panel.add(title);
        panel.add(Box.createVerticalStrut(15));
        panel.add(userField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(amountField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(addButton);
        panel.add(Box.createVerticalStrut(10));
        panel.add(searchField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(ticketsButton);
        panel.add(Box.createVerticalStrut(10));
        panel.add(refreshBtn);
        panel.add(Box.createVerticalStrut(10));

        JLabel listLabel = new JLabel("User Accounts");
        listLabel.setForeground(new Color(30, 30, 30));
        listLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        listLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(listLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(scrollPane);
        panel.add(Box.createVerticalStrut(15));
        panel.add(logoutButton);
        panel.add(Box.createVerticalStrut(15));

        add(panel);
        refreshUserList("");
        setVisible(true);
    }

    private void refreshUserList(String filter) {
        usersPanel.removeAll();
        UserService service = new UserService();
        List<User> users = service.loadAllUsers();
        users = users.stream()
                .filter(u -> !u.getUsername().equalsIgnoreCase("admin"))
                .filter(u -> u.getUsername().toLowerCase().contains(filter.toLowerCase()))
                .collect(Collectors.toList());
        for (User user : users) {
            RoundedPanel card = new RoundedPanel(18);
            card.setLayout(new BorderLayout());
            card.setBorder(new EmptyBorder(10, 15, 10, 15));
            card.setBackground(Color.WHITE);
            card.setMaximumSize(new Dimension(650, 90));
            JLabel info = new JLabel("<html><b>User:</b> " + user.getUsername() +
                    " &nbsp;&nbsp;&nbsp;&nbsp; <b>Email:</b> " + user.getEmail() +
                    " &nbsp;&nbsp;&nbsp;&nbsp; <b>Balance:</b> " + user.getBalance() +
                    " &nbsp;&nbsp;&nbsp;&nbsp; <b>Status:</b> " + user.getStatus() + "</html>");
            info.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            info.setBorder(new EmptyBorder(5, 5, 5, 5));
            JPanel buttonPanel = new JPanel();
            buttonPanel.setBackground(Color.WHITE);
            JButton deleteBtn = new JButton("Delete");
            JButton blockBtn = new JButton(user.getStatus().equals("blocked") ? "Unblock" : "Block");
            if (user.getStatus().equals("blocked")) {
                blockBtn.setBackground(new Color(0, 150, 0));
                blockBtn.setForeground(Color.WHITE);
            } else {
                blockBtn.setBackground(new Color(200, 0, 0));
                blockBtn.setForeground(Color.WHITE);
            }
            deleteBtn.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(this, "Delete user " + user.getUsername() + "?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    service.deleteUser(user.getUsername());
                    refreshUserList(searchField.getText().trim());
                }
            });
            blockBtn.addActionListener(e -> {
                String newStatus = user.getStatus().equals("blocked") ? "active" : "blocked";
                service.setStatus(user.getUsername(), newStatus);
                refreshUserList(searchField.getText().trim());
            });
            buttonPanel.add(deleteBtn);
            buttonPanel.add(blockBtn);
            card.add(info, BorderLayout.CENTER);
            card.add(buttonPanel, BorderLayout.SOUTH);
            usersPanel.add(Box.createVerticalStrut(5));
            usersPanel.add(card);
        }
        usersPanel.revalidate();
        usersPanel.repaint();
    }

    private void openTicketViewer() {
        JFrame frame = new JFrame("Support Tickets");
        frame.setSize(600, 500);
        frame.setLocationRelativeTo(this);
        frame.setLayout(new BorderLayout());
        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Active Tickets", createTicketPanel("support_requests.txt", true));
        tabs.add("Resolved Tickets", createTicketPanel("support_requests_resolved.txt", false));
        frame.add(tabs, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private JPanel createTicketPanel(String filePath, boolean showResolveButton) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(panel);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                file.createNewFile();
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                final String ticketLine = line;
                String username = ticketLine.split("\\|")[0].trim();
                JPanel card = new JPanel(new BorderLayout());
                card.setBorder(new EmptyBorder(8, 12, 8, 12));
                card.setBackground(new Color(245, 245, 245));
                JButton viewBtn = new JButton(username);
                viewBtn.setBackground(new Color(50, 50, 120));
                viewBtn.setForeground(Color.WHITE);
                viewBtn.addActionListener(e -> showFullTicket(ticketLine));
                card.add(viewBtn, BorderLayout.CENTER);
                if (showResolveButton) {
                    JButton resolveBtn = new JButton("Mark as Resolved");
                    resolveBtn.setBackground(new Color(30, 130, 30));
                    resolveBtn.setForeground(Color.WHITE);
                    resolveBtn.addActionListener(e -> {
                        moveToResolved(ticketLine);
                        SwingUtilities.getWindowAncestor(resolveBtn).dispose();
                        openTicketViewer();
                    });
                    card.add(resolveBtn, BorderLayout.EAST);
                }
                panel.add(card);
                panel.add(Box.createVerticalStrut(10));
            }
            reader.close();
        } catch (IOException ignored) {}
        JPanel container = new JPanel(new BorderLayout());
        container.add(scroll, BorderLayout.CENTER);
        return container;
    }

    private void moveToResolved(String ticketLine) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("support_requests.txt"));
            BufferedWriter writer = new BufferedWriter(new FileWriter("support_requests_temp.txt"));
            BufferedWriter resolvedWriter = new BufferedWriter(new FileWriter("support_requests_resolved.txt", true));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().equals(ticketLine.trim())) {
                    resolvedWriter.write(line);
                    resolvedWriter.newLine();
                } else {
                    writer.write(line);
                    writer.newLine();
                }
            }
            reader.close();
            writer.close();
            resolvedWriter.close();
            new File("support_requests.txt").delete();
            new File("support_requests_temp.txt").renameTo(new File("support_requests.txt"));
        } catch (IOException ignored) {}
    }

    private void showFullTicket(String ticketLine) {
        JDialog dialog = new JDialog(this, "Ticket", true);
        dialog.setSize(500, 300);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        JPanel panel = new JPanel();
        panel.setBackground(new Color(230, 235, 245));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JTextArea area = new JTextArea(ticketLine);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        area.setEditable(false);
        area.setOpaque(false);
        area.setBorder(new EmptyBorder(20, 20, 20, 20));
        JButton closeBtn = new JButton("Close");
        closeBtn.setBackground(new Color(50, 50, 120));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setMaximumSize(new Dimension(200, 35));
        closeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        closeBtn.addActionListener(e -> dialog.dispose());
        panel.add(area);
        panel.add(Box.createVerticalStrut(15));
        panel.add(closeBtn);
        panel.add(Box.createVerticalStrut(15));
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }
}
