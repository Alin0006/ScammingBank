package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class YourDataScreen extends JFrame {

    public YourDataScreen() {
        setTitle("Your data");
        setSize(450, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);
        Color textColor = Color.WHITE;

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundColor);

        JButton backButton = new JButton("←");
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(e -> dispose());

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(backgroundColor);
        topBar.add(backButton, BorderLayout.WEST);

        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(backgroundColor);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 20, 30));

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png"))
                .getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH)));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Your data");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        JTextArea textArea = new JTextArea();
        textArea.setText(
                "ScammingBank does not collect or transmit any personal data externally.\n"
                        + "All information you enter — including usernames, account balances, and credentials — is saved locally on your device, strictly for educational purposes.\n\n"
                        + "This data is not accessible to the developer or any third party.\n"
                        + "However, if you share your project files with others, they may be able to see the data stored on your machine.\n\n"
                        + "ScammingBank does not use cookies, location tracking, or online analytics.\n"
                        + "Everything happens on your device, offline, and under your control.");
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setEditable(false);
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textArea.setForeground(Color.WHITE);
        textArea.setBackground(backgroundColor);
        textArea.setCaretPosition(0);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(backgroundColor);
        scrollPane.setPreferredSize(new Dimension(380, 300));
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

        JLabel signature = new JLabel("© 2025 Alin Adrian Dragomir");
        signature.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        signature.setForeground(Color.LIGHT_GRAY);
        signature.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 0));
        signature.setHorizontalAlignment(SwingConstants.LEFT);

        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(backgroundColor);
        footerPanel.add(signature, BorderLayout.WEST);

        contentPanel.add(logo);
        contentPanel.add(title);
        contentPanel.add(scrollPane);

        mainPanel.add(topBar, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }
}
