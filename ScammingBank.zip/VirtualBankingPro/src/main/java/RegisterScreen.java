package com.virtualbank;

import com.virtualbank.ui.RegisterCard;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class RegisterScreen extends JFrame {

    public RegisterScreen() {
        setTitle("Register");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(backgroundColor);

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH)));
        logo.setBounds(237, 10, 130, 130);

        JButton backButton = new JButton();
        backButton.setIcon(new ImageIcon(getClass().getResource("/icons/arrow_back_24dp_1F1F1F.png")));
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(110, 145, 48, 48);
        backButton.addActionListener(e -> {
            dispose();
            new HomeScreen().setVisible(true);
        });

        RegisterCard registerCard = new RegisterCard();
        registerCard.setBounds(100, 140, 400, 380);

        registerCard.registerButton.addActionListener(e -> {
            String username = registerCard.usernameField.getText();
            String email = registerCard.emailField.getText();
            String password = new String(registerCard.passwordField.getPassword());
            String confirmPassword = new String(registerCard.confirmPasswordField.getPassword());
            boolean acceptedTerms = registerCard.termsCheckbox.isSelected();

            if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email address", "Invalid Email", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!acceptedTerms) {
                JOptionPane.showMessageDialog(this, "You must accept the terms and conditions", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            UserService userService = new UserService();

            if (userService.emailExists(email)) {
                JOptionPane.showMessageDialog(this, "This email address is already registered", "Email In Use", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (userService.userExists(username)) {
                JOptionPane.showMessageDialog(this, "Username is already taken", "Username In Use", JOptionPane.ERROR_MESSAGE);
                return;
            }

            User newUser = new User(username, email, password, 0.0);
            boolean success = userService.register(newUser);

            if (!success) {
                JOptionPane.showMessageDialog(this, "Error saving user. Please try again.", "Registration Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ImageIcon logoIcon = new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));

            JDialog dialog = new JDialog(this, "Registration Complete", true);
            dialog.setSize(400, 260);
            dialog.setLayout(new BorderLayout());
            dialog.setUndecorated(false);
            dialog.setLocationRelativeTo(this);

            JPanel panel = new JPanel();
            panel.setBackground(new Color(30, 60, 90));
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            JLabel iconLabel = new JLabel(logoIcon);
            iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            JTextPane messagePane = new JTextPane();
            messagePane.setContentType("text/html");
            messagePane.setText("<div style='text-align: center; color: white; font-family: Segoe UI; font-size: 13px;'>Your bank account has been successfully created.<br>You can now log in using your credentials.</div>");
            messagePane.setEditable(false);
            messagePane.setOpaque(false);
            messagePane.setFocusable(false);
            messagePane.setMaximumSize(new Dimension(360, 50));
            messagePane.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton okButton = new JButton("OK");
            okButton.setBackground(Color.BLACK);
            okButton.setForeground(Color.WHITE);
            okButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
            okButton.setFocusPainted(false);
            okButton.setPreferredSize(new Dimension(300, 40));
            okButton.setMaximumSize(new Dimension(300, 40));
            okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            okButton.addActionListener(ev -> {
                dialog.dispose();
                dispose();
                new LoginScreen().setVisible(true);
            });

            panel.add(Box.createVerticalStrut(15));
            panel.add(iconLabel);
            panel.add(Box.createVerticalStrut(5));
            panel.add(messagePane);
            panel.add(Box.createVerticalStrut(15));
            panel.add(okButton);
            panel.add(Box.createVerticalStrut(15));

            dialog.add(panel);
            dialog.setResizable(false);
            dialog.setVisible(true);
        });

        mainPanel.add(logo);
        mainPanel.add(backButton);
        mainPanel.add(registerCard);
        add(mainPanel);
    }
}
