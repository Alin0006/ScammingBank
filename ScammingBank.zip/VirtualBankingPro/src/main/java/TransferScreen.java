package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TransferScreen extends JFrame {

    private final String username;

    public TransferScreen(String username) {
        this.username = username;
        setTitle("Transfer");
        setSize(400, 360);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color bgColor = new Color(30, 35, 50);
        Color textColor = Color.WHITE;

        UserService userService = new UserService();
        User currentUser = userService.loadUser(username);
        double balance = currentUser != null ? currentUser.getBalance() : 0.0;

        JPanel panel = new JPanel();
        panel.setBackground(bgColor);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(25, 40, 25, 40));

        JLabel title = new JLabel("Send Money");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel balanceLabel = new JLabel("Balance: £" + String.format("%.2f", balance));
        balanceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        balanceLabel.setForeground(Color.LIGHT_GRAY);
        balanceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField recipientField = new JTextField("Recipient Username");
        recipientField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        recipientField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        recipientField.setAlignmentX(Component.CENTER_ALIGNMENT);
        recipientField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 65, 85)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        recipientField.setBackground(new Color(45, 50, 70));
        recipientField.setForeground(Color.GRAY);
        recipientField.setCaretColor(Color.WHITE);
        recipientField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (recipientField.getText().equals("Recipient Username")) {
                    recipientField.setText("");
                    recipientField.setForeground(Color.WHITE);
                }
            }
            public void focusLost(FocusEvent e) {
                if (recipientField.getText().isEmpty()) {
                    recipientField.setText("Recipient Username");
                    recipientField.setForeground(Color.GRAY);
                }
            }
        });

        JTextField amountField = new JTextField("Amount");
        amountField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        amountField.setAlignmentX(Component.CENTER_ALIGNMENT);
        amountField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 65, 85)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        amountField.setBackground(new Color(45, 50, 70));
        amountField.setForeground(Color.GRAY);
        amountField.setCaretColor(Color.WHITE);
        amountField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (amountField.getText().equals("Amount")) {
                    amountField.setText("");
                    amountField.setForeground(Color.WHITE);
                }
            }
            public void focusLost(FocusEvent e) {
                if (amountField.getText().isEmpty()) {
                    amountField.setText("Amount");
                    amountField.setForeground(Color.GRAY);
                }
            }
        });

        JButton sendButton = new JButton("Send");
        sendButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        sendButton.setFocusPainted(false);
        sendButton.setBackground(new Color(0, 120, 215));
        sendButton.setForeground(Color.WHITE);
        sendButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        sendButton.setMaximumSize(new Dimension(100, 35));

        JLabel messageLabel = new JLabel(" ");
        messageLabel.setForeground(Color.LIGHT_GRAY);
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        sendButton.addActionListener(e -> {
            String recipient = recipientField.getText().trim();
            String amountText = amountField.getText().trim();
            if (recipient.isEmpty() || amountText.isEmpty() || recipient.equals("Recipient Username") || amountText.equals("Amount")) {
                messageLabel.setText("All fields are required.");
                return;
            }
            try {
                double amount = Double.parseDouble(amountText);
                if (amount <= 0) {
                    messageLabel.setText("Enter a valid amount.");
                    return;
                }
                User sender = userService.loadUser(username);
                User receiver = userService.loadUser(recipient);
                if (receiver == null) {
                    messageLabel.setText("Recipient not found.");
                    return;
                }
                if (sender.getBalance() < amount) {
                    messageLabel.setText("Insufficient balance.");
                    return;
                }
                userService.updateBalance(username, -amount);
                userService.updateBalance(recipient, amount);
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("transactions.txt", true))) {
                    writer.write(username + " -> " + recipient + " : £" + String.format("%.2f", amount));
                    writer.newLine();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                Dashboard refreshed = new Dashboard(username);
                refreshed.setVisible(true);
                dispose();
            } catch (NumberFormatException ex) {
                messageLabel.setText("Invalid amount.");
            }
        });

        panel.add(title);
        panel.add(Box.createVerticalStrut(8));
        panel.add(balanceLabel);
        panel.add(Box.createVerticalStrut(15));
        panel.add(recipientField);
        panel.add(Box.createVerticalStrut(12));
        panel.add(amountField);
        panel.add(Box.createVerticalStrut(20));
        panel.add(sendButton);
        panel.add(Box.createVerticalStrut(15));
        panel.add(messageLabel);

        add(panel);
    }
}
