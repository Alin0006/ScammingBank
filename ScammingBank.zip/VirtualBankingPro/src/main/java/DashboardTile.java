package com.virtualbank.ui;

import javax.swing.*;
import java.awt.*;

public class DashboardTile extends JPanel {

    private final JLabel titleLabel;

    public DashboardTile(String title, Color backgroundColor) {
        setPreferredSize(new Dimension(150, 120));
        setBackground(backgroundColor);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);

        add(titleLabel, BorderLayout.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int arc = 20;
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);

        g2.dispose();
        super.paintComponent(g);
    }
}
