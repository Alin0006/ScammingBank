package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.DecimalFormat;

public class CryptoTradeScreen extends JFrame {
    private final String username;
    private final String cryptoSymbol;
    private final double cryptoPrice;
    private double fiatBalance;
    private double cryptoBalance;

    private JLabel lblFiat, lblCrypto, lblPrice;
    private JTextField amountField;
    private com.virtualbank.CryptoScreen parentScreen;

    public CryptoTradeScreen(String username, String cryptoSymbol, double cryptoPrice, double fiatBalance, double cryptoBalance, com.virtualbank.CryptoScreen parentScreen) {
        this.username = username;
        this.cryptoSymbol = cryptoSymbol;
        this.cryptoPrice = cryptoPrice;
        this.fiatBalance = fiatBalance;
        this.cryptoBalance = cryptoBalance;
        this.parentScreen = parentScreen;

        setTitle("Trade " + cryptoSymbol);
        setSize(420, 360);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setLayout(null);
        getContentPane().setBackground(new Color(30, 35, 50));

        JLabel title = new JLabel("Trade " + cryptoSymbol);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        title.setBounds(30, 20, 300, 30);
        add(title);

        lblPrice = new JLabel("Price: £" + format(cryptoPrice));
        lblPrice.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPrice.setForeground(Color.LIGHT_GRAY);
        lblPrice.setBounds(30, 60, 300, 20);
        add(lblPrice);

        lblFiat = new JLabel("Available Funds: £" + format(fiatBalance));
        lblFiat.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblFiat.setForeground(Color.LIGHT_GRAY);
        lblFiat.setBounds(30, 90, 300, 20);
        add(lblFiat);

        lblCrypto = new JLabel("You own: " + format(cryptoBalance) + " " + cryptoSymbol);
        lblCrypto.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblCrypto.setForeground(Color.LIGHT_GRAY);
        lblCrypto.setBounds(30, 120, 300, 20);
        add(lblCrypto);

        amountField = new JTextField();
        amountField.setBounds(30, 160, 340, 35);
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        add(amountField);

        JButton buyBtn = new JButton("Buy");
        buyBtn.setBounds(30, 210, 150, 40);
        buyBtn.setBackground(new Color(0, 140, 60));
        buyBtn.setForeground(Color.WHITE);
        buyBtn.setFocusPainted(false);
        buyBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        buyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        buyBtn.addActionListener(e -> handleTransaction(true));
        add(buyBtn);

        JButton sellBtn = new JButton("Sell");
        sellBtn.setBounds(220, 210, 150, 40);
        sellBtn.setBackground(new Color(140, 0, 0));
        sellBtn.setForeground(Color.WHITE);
        sellBtn.setFocusPainted(false);
        sellBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sellBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sellBtn.addActionListener(e -> handleTransaction(false));
        add(sellBtn);

        JButton closeBtn = new JButton("Close");
        closeBtn.setBounds(140, 270, 120, 35);
        closeBtn.setBackground(new Color(100, 100, 100));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFocusPainted(false);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeBtn.addActionListener(e -> dispose());
        add(closeBtn);

        setVisible(true);
    }

    private void handleTransaction(boolean isBuy) {
        try {
            double amount = Double.parseDouble(amountField.getText());
            double value = amount * cryptoPrice;

            if (isBuy) {
                if (value > fiatBalance) {
                    showError("Insufficient funds.");
                    return;
                }
                fiatBalance -= value;
                cryptoBalance += amount;
            } else {
                if (amount > cryptoBalance) {
                    showError("Not enough " + cryptoSymbol + " to sell.");
                    return;
                }
                fiatBalance += value;
                cryptoBalance -= amount;
            }

            saveTransaction(isBuy ? "BUY" : "SELL", amount, value);
            saveToMainTransactionFile(isBuy ? "BUY" : "SELL", value);
            saveCryptoBalance();
            updateUserFiatBalance();
            updateLabels();

            if (parentScreen != null) {
                parentScreen.loadLatestData();
                parentScreen.updateAll();
                parentScreen.updateFiatBalance();
            }

            Dashboard.refreshBalanceExtern(username);
            Dashboard.refreshTransactionListExtern();

        } catch (NumberFormatException e) {
            showError("Invalid amount.");
        }
    }

    private void saveTransaction(String type, double cryptoAmount, double fiatValue) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("crypto_transactions.txt", true))) {
            writer.write(username + " | " + type + " | " + cryptoAmount + " " + cryptoSymbol + " @ £" + format(cryptoPrice) + " = £" + format(fiatValue));
            writer.newLine();
        } catch (IOException e) {
            showError("Failed to save transaction.");
        }
    }

    private void saveToMainTransactionFile(String type, double fiatValue) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("transactions.txt", true))) {
            if (type.equals("BUY")) {
                writer.write(username + " -> Crypto: £" + String.format("%.2f", fiatValue));
            } else {
                writer.write("Crypto -> " + username + ": £" + String.format("%.2f", fiatValue));
            }
            writer.newLine();
        } catch (IOException e) {
        }
    }

    private void saveCryptoBalance() {
        File file = new File("crypto_balances.txt");
        String newLine = username + " | " + cryptoSymbol + "=" + format(cryptoBalance);
        try {
            boolean updated = false;
            StringBuilder allData = new StringBuilder();
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith(username + " |")) {
                        String[] parts = line.split("\\|");
                        StringBuilder newLineBuilder = new StringBuilder(username);
                        for (String part : parts) {
                            if (part.trim().startsWith(cryptoSymbol + "=")) {
                                newLineBuilder.append(" | ").append(cryptoSymbol).append("=").append(format(cryptoBalance));
                            } else if (!part.trim().equals(username)) {
                                newLineBuilder.append(" | ").append(part.trim());
                            }
                        }
                        if (!line.contains(cryptoSymbol + "=")) {
                            newLineBuilder.append(" | ").append(cryptoSymbol).append("=").append(format(cryptoBalance));
                        }
                        allData.append(newLineBuilder).append("\n");
                        updated = true;
                    } else {
                        allData.append(line).append("\n");
                    }
                }
                reader.close();
            }
            if (!updated) {
                allData.append(newLine).append("\n");
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(allData.toString());
            writer.close();
        } catch (IOException e) {
            showError("Error saving crypto balances.");
        }
    }

    private void updateUserFiatBalance() {
        File file = new File("users.txt");
        if (!file.exists()) return;
        StringBuilder allData = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 5 && parts[0].equals(username)) {
                    parts[3] = String.format("%.2f", fiatBalance);
                    StringBuilder updatedLine = new StringBuilder();
                    for (int i = 0; i < parts.length; i++) {
                        updatedLine.append(parts[i].trim());
                        if (i < parts.length - 1) updatedLine.append(";");
                    }
                    allData.append(updatedLine).append("\n");
                } else {
                    allData.append(line).append("\n");
                }
            }
            reader.close();
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(allData.toString());
            writer.close();
        } catch (IOException e) {
        }
    }

    private void updateLabels() {
        lblFiat.setText("Available Funds: £" + format(fiatBalance));
        lblCrypto.setText("You own: " + format(cryptoBalance) + " " + cryptoSymbol);
        amountField.setText("");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Transaction Error", JOptionPane.ERROR_MESSAGE);
    }

    private String format(double value) {
        return new DecimalFormat("#,##0.0000").format(value);
    }

    @Override
    public void dispose() {
        if (parentScreen != null) {
            parentScreen.loadLatestData();
            parentScreen.updateAll();
            parentScreen.updateFiatBalance();
        }
        Dashboard.refreshBalanceExtern(username);
        Dashboard.refreshTransactionListExtern();
        super.dispose();
    }
}
