package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ContactDetailsWindow extends JDialog {
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField addressField;

    private static final String FILE_NAME = "contact_details.properties";

    public ContactDetailsWindow(JFrame parent, String username) {
        super(parent, "Edit contact details", true);
        setSize(400, 320);
        setLocationRelativeTo(parent);
        getContentPane().setBackground(new Color(24, 28, 44));
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Edit contact details");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        phoneField = new JTextField();
        emailField = new JTextField();
        addressField = new JTextField();

        add(Box.createVerticalStrut(10));
        add(titleLabel);
        add(createInputPanel("Phone", phoneField));
        add(createInputPanel("Email", emailField));
        add(createInputPanel("Address", addressField));

        JButton saveButton = new JButton("Save");
        saveButton.setBackground(new Color(0, 120, 215));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFocusPainted(false);
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveButton.setMaximumSize(new Dimension(150, 35));
        saveButton.addActionListener(e -> {
            Properties props = new Properties();
            props.setProperty("phone", phoneField.getText());
            props.setProperty("email", emailField.getText());
            props.setProperty("address", addressField.getText());

            try (FileOutputStream fos = new FileOutputStream(FILE_NAME)) {
                props.store(fos, "Contact details");
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            dispose();
        });

        loadSavedDetails();
        add(Box.createVerticalStrut(15));
        add(saveButton);
    }

    private JPanel createInputPanel(String label, JTextField field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(24, 28, 44));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 40, 0, 40));

        JLabel jLabel = new JLabel(label);
        jLabel.setForeground(Color.WHITE);
        panel.add(jLabel, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    private void loadSavedDetails() {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(FILE_NAME)) {
            props.load(fis);
            phoneField.setText(props.getProperty("phone", ""));
            emailField.setText(props.getProperty("email", ""));
            addressField.setText(props.getProperty("address", ""));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
