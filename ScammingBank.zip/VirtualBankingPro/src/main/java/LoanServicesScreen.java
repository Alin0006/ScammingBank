package com.virtualbank;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class LoanServicesScreen extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable activeTable;
    private JTable pendingTable;
    private JTable paidTable;
    private DefaultTableModel activeModel;
    private DefaultTableModel pendingModel;
    private DefaultTableModel paidModel;
    private ArrayList<Loan> activeLoans;
    private ArrayList<Loan> pendingLoans;
    private ArrayList<Loan> paidLoans;
    private int selectedActive = -1;
    private int selectedPending = -1;
    private int selectedPaid = -1;
    private String username;

    public LoanServicesScreen(String username) {
        this.username = username;
        setTitle("Loan Services");
        setSize(880, 630);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel panel = new JPanel();
        panel.setBackground(new Color(21, 24, 37));
        panel.setLayout(null);

        JLabel title = new JLabel("Loan Services");
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setBounds(320, 18, 400, 36);
        panel.add(title);

        JLabel subtitle = new JLabel("Manage your loans: apply, view status, see history, all in one place.");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtitle.setForeground(new Color(180, 200, 235));
        subtitle.setBounds(220, 54, 550, 22);
        panel.add(subtitle);

        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 16));
        tabbedPane.setBackground(new Color(30, 32, 50));
        tabbedPane.setForeground(Color.WHITE);
        tabbedPane.setBounds(36, 90, 790, 320);

        activeModel = new DefaultTableModel(new Object[]{"Loan ID", "Amount", "Type", "Monthly Rate", "Status", "Next Payment", "Due Date"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        activeTable = new JTable(activeModel);
        activeTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        activeTable.setRowHeight(28);
        activeTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
        activeTable.getTableHeader().setBackground(new Color(36,42,65));
        activeTable.getTableHeader().setForeground(Color.WHITE);
        activeTable.setBackground(new Color(30,32,50));
        activeTable.setForeground(Color.WHITE);
        activeTable.setSelectionBackground(new Color(44,64,104));
        JScrollPane activeScroll = new JScrollPane(activeTable);
        activeScroll.setBounds(0, 0, 775, 265);
        JPanel activePanel = new JPanel(null);
        activePanel.setBackground(new Color(30, 32, 50));
        activePanel.add(activeScroll);

        pendingModel = new DefaultTableModel(new Object[]{"Loan ID", "Amount", "Type", "Status", "Submitted"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        pendingTable = new JTable(pendingModel);
        pendingTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        pendingTable.setRowHeight(28);
        pendingTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
        pendingTable.getTableHeader().setBackground(new Color(36,42,65));
        pendingTable.getTableHeader().setForeground(Color.WHITE);
        pendingTable.setBackground(new Color(30,32,50));
        pendingTable.setForeground(Color.WHITE);
        pendingTable.setSelectionBackground(new Color(44,64,104));
        JScrollPane pendingScroll = new JScrollPane(pendingTable);
        pendingScroll.setBounds(0, 0, 775, 265);
        JPanel pendingPanel = new JPanel(null);
        pendingPanel.setBackground(new Color(30, 32, 50));
        pendingPanel.add(pendingScroll);

        paidModel = new DefaultTableModel(new Object[]{"Loan ID", "Amount", "Type", "Monthly Rate", "Paid Off Date"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        paidTable = new JTable(paidModel);
        paidTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        paidTable.setRowHeight(28);
        paidTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
        paidTable.getTableHeader().setBackground(new Color(36,42,65));
        paidTable.getTableHeader().setForeground(Color.WHITE);
        paidTable.setBackground(new Color(30,32,50));
        paidTable.setForeground(Color.WHITE);
        paidTable.setSelectionBackground(new Color(44,64,104));
        JScrollPane paidScroll = new JScrollPane(paidTable);
        paidScroll.setBounds(0, 0, 775, 265);
        JPanel paidPanel = new JPanel(null);
        paidPanel.setBackground(new Color(30, 32, 50));
        paidPanel.add(paidScroll);

        tabbedPane.addTab("Active Loans", activePanel);
        tabbedPane.addTab("Pending Applications", pendingPanel);
        tabbedPane.addTab("Paid Off", paidPanel);
        panel.add(tabbedPane);

        activeLoans = new ArrayList<>();
        pendingLoans = new ArrayList<>();
        paidLoans = new ArrayList<>();
        loadAllLoans();

        JButton apply = new JButton("Request a New Loan");
        apply.setFont(new Font("Segoe UI", Font.BOLD, 17));
        apply.setBackground(new Color(0, 170, 105));
        apply.setForeground(Color.WHITE);
        apply.setBounds(90, 440, 220, 48);
        panel.add(apply);

        JButton repay = new JButton("Repay Loan");
        repay.setFont(new Font("Segoe UI", Font.BOLD, 16));
        repay.setBackground(new Color(70, 90, 185));
        repay.setForeground(Color.WHITE);
        repay.setBounds(340, 440, 170, 48);
        repay.setEnabled(false);
        panel.add(repay);

        JButton details = new JButton("View Details");
        details.setFont(new Font("Segoe UI", Font.BOLD, 16));
        details.setBackground(new Color(37, 41, 65));
        details.setForeground(Color.WHITE);
        details.setBounds(540, 440, 170, 48);
        details.setEnabled(false);
        panel.add(details);

        JLabel info = new JLabel("For assistance, contact support@scammingbank.co.uk");
        info.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        info.setForeground(new Color(150, 160, 185));
        info.setBounds(230, 515, 400, 28);
        panel.add(info);

        activeTable.getSelectionModel().addListSelectionListener(e -> {
            selectedActive = activeTable.getSelectedRow();
            if (selectedActive >= 0 && activeLoans.size() > 0) {
                repay.setEnabled("Active".equals(activeModel.getValueAt(selectedActive, 4)));
                details.setEnabled(true);
            } else {
                repay.setEnabled(false);
                details.setEnabled(false);
            }
        });

        pendingTable.getSelectionModel().addListSelectionListener(e -> {
            selectedPending = pendingTable.getSelectedRow();
        });

        paidTable.getSelectionModel().addListSelectionListener(e -> {
            selectedPaid = paidTable.getSelectedRow();
        });

        apply.addActionListener(e -> openLoanApplication());
        repay.addActionListener(e -> repayLoan());
        details.addActionListener(e -> showDetails());

        add(panel);
        setVisible(true);
    }

    public LoanServicesScreen() {
    this(LoginScreen.currentUser);
}

    private void loadAllLoans() {
        activeLoans.clear();
        pendingLoans.clear();
        paidLoans.clear();
        activeModel.setRowCount(0);
        pendingModel.setRowCount(0);
        paidModel.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader("loan_requests.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] s = line.split(";");
                if (s.length == 7) {
                    if (s[6].equals("APPROVED")) {
                        activeLoans.add(new Loan(s[0], Integer.parseInt(s[2]), s[3], Integer.parseInt(s[4]), s[5], "Active", "12/2025"));
                        activeModel.addRow(new Object[]{s[0], "£" + s[2], s[3], "£" + s[4], "Active", s[5], "12/2025"});
                    }
                    if (s[6].equals("PENDING")) {
                        pendingLoans.add(new Loan(s[0], Integer.parseInt(s[2]), s[3], Integer.parseInt(s[4]), s[5], "Pending", s[5]));
                        pendingModel.addRow(new Object[]{s[0], "£" + s[2], s[3], "Pending", s[5]});
                    }
                    if (s[6].equals("PAID")) {
                        paidLoans.add(new Loan(s[0], Integer.parseInt(s[2]), s[3], Integer.parseInt(s[4]), s[5], "Paid", s[5]));
                        paidModel.addRow(new Object[]{s[0], "£" + s[2], s[3], "£" + s[4], s[5]});
                    }
                }
            }
        } catch (Exception ignored) {}
        if (activeLoans.isEmpty()) {
            activeModel.addRow(new Object[]{"", "No active loans", "", "", "", "", ""});
        }
        if (pendingLoans.isEmpty()) {
            pendingModel.addRow(new Object[]{"", "No pending applications", "", "", ""});
        }
        if (paidLoans.isEmpty()) {
            paidModel.addRow(new Object[]{"", "No paid off loans", "", "", ""});
        }
    }

    private void openLoanApplication() {
        JDialog dialog = new JDialog(this, "Loan Application", true);
        dialog.setSize(460, 460);
        dialog.setLayout(null);
        dialog.getContentPane().setBackground(new Color(27,32,54));

        JLabel l1 = new JLabel("Loan Amount:");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l1.setBounds(38,35,140,28);

        JTextField amountField = new JTextField();
        amountField.setBounds(170,35,200,28);

        JLabel l2 = new JLabel("Type:");
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l2.setBounds(38,85,100,28);

        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Personal","Car","Education","Mortgage","Business"});
        typeBox.setBounds(170,85,200,28);

        JLabel l3 = new JLabel("Term (months):");
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l3.setBounds(38,135,130,28);

        JTextField termField = new JTextField();
        termField.setBounds(170,135,200,28);

        JLabel l4 = new JLabel("Reason:");
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l4.setBounds(38,185,100,28);

        JTextArea reasonField = new JTextArea();
        reasonField.setLineWrap(true);
        reasonField.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(reasonField);
        scroll.setBounds(170,185,200,60);

        JButton submit = new JButton("Submit Application");
        submit.setFont(new Font("Segoe UI", Font.BOLD, 16));
        submit.setBackground(new Color(0, 170, 105));
        submit.setForeground(Color.WHITE);
        submit.setBounds(125, 280, 200, 44);

        dialog.add(l1); dialog.add(amountField);
        dialog.add(l2); dialog.add(typeBox);
        dialog.add(l3); dialog.add(termField);
        dialog.add(l4); dialog.add(scroll);
        dialog.add(submit);

        submit.addActionListener(e -> {
            String amount = amountField.getText().trim();
            String type = (String) typeBox.getSelectedItem();
            String term = termField.getText().trim();
            String reason = reasonField.getText().trim();
            if (amount.isEmpty() || type.isEmpty() || term.isEmpty() || reason.isEmpty()) {
                JOptionPane.showMessageDialog(dialog,"Complete all fields.","Missing data",JOptionPane.WARNING_MESSAGE);
                return;
            }
            String currentUser = this.username;
            try (BufferedWriter bw = new BufferedWriter(new FileWriter("loan_requests.txt", true))) {
                String id = "LN" + System.currentTimeMillis();
                String line = id + ";" + currentUser + ";" + amount + ";" + type + ";" + term + ";" + reason + ";PENDING";
                bw.write(line);
                bw.newLine();
                try (BufferedWriter admin = new BufferedWriter(new FileWriter("loan_applications.txt", true))) {
                    admin.write("Loan ID: " + id);
                    admin.newLine();
                    admin.write("User: " + currentUser);
                    admin.newLine();
                    admin.write("Amount: £" + amount);
                    admin.newLine();
                    admin.write("Type: " + type);
                    admin.newLine();
                    admin.write("Term: " + term + " months");
                    admin.newLine();
                    admin.write("Reason: " + reason);
                    admin.newLine();
                    admin.write("Status: PENDING");
                    admin.newLine();
                    admin.write("--------------------------------------------------");
                    admin.newLine();
                }
            } catch (Exception ignored) {}
            dialog.dispose();
            loadAllLoans();
            JDialog confirm = new JDialog(this, "Application Submitted", true);
            confirm.setSize(360, 160);
            confirm.setLayout(null);
            confirm.getContentPane().setBackground(new Color(32, 36, 58));
            JLabel msg = new JLabel("Your loan application was sent to our staff.");
            msg.setForeground(Color.WHITE);
            msg.setFont(new Font("Segoe UI", Font.PLAIN, 15));
            msg.setBounds(40, 30, 300, 25);
            JButton ok = new JButton("OK");
            ok.setBackground(new Color(0,170,105));
            ok.setForeground(Color.WHITE);
            ok.setBounds(120, 70, 100, 32);
            ok.addActionListener(e2 -> confirm.dispose());
            confirm.add(msg);
            confirm.add(ok);
            confirm.setLocationRelativeTo(this);
            confirm.setVisible(true);
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void repayLoan() {
        if (selectedActive >= 0 && activeLoans.size() > selectedActive && activeLoans.get(selectedActive).status.equals("Active")) {
            Loan loan = activeLoans.get(selectedActive);
            JDialog confirmDialog = new JDialog(this, "Confirm Repayment", true);
            confirmDialog.setSize(400, 180);
            confirmDialog.setLayout(null);
            confirmDialog.getContentPane().setBackground(new Color(30, 32, 48));

            JLabel message = new JLabel("Repay monthly rate (£" + loan.monthly + ")?");
            message.setForeground(Color.WHITE);
            message.setFont(new Font("Segoe UI", Font.PLAIN, 15));
            message.setBounds(60, 30, 300, 25);
            confirmDialog.add(message);

            JButton yesButton = new JButton("Yes");
            yesButton.setBounds(80, 80, 100, 35);
            yesButton.setBackground(new Color(0, 170, 105));
            yesButton.setForeground(Color.WHITE);
            confirmDialog.add(yesButton);

            JButton cancelButton = new JButton("Cancel");
            cancelButton.setBounds(220, 80, 100, 35);
            cancelButton.setBackground(new Color(120, 30, 30));
            cancelButton.setForeground(Color.WHITE);
            confirmDialog.add(cancelButton);

            yesButton.addActionListener(e -> {
                setLoanPaid(activeLoans.get(selectedActive).id);
                updateBalanceAfterRepayment(loan.monthly);
                confirmDialog.dispose();
                loadAllLoans();
                JDialog successDialog = new JDialog(this, "Payment Successful", true);
                successDialog.setSize(360, 160);
                successDialog.setLayout(null);
                successDialog.getContentPane().setBackground(new Color(32, 36, 58));
                JLabel msg = new JLabel("Loan marked as paid for this month!");
                msg.setForeground(Color.WHITE);
                msg.setFont(new Font("Segoe UI", Font.PLAIN, 15));
                msg.setBounds(40, 30, 300, 25);
                JButton ok = new JButton("OK");
                ok.setBackground(new Color(0,170,105));
                ok.setForeground(Color.WHITE);
                ok.setBounds(120, 70, 100, 32);
                ok.addActionListener(e2 -> {
                    successDialog.dispose();
                    dispose();
                });
                successDialog.add(msg);
                successDialog.add(ok);
                successDialog.setLocationRelativeTo(this);
                successDialog.setVisible(true);
            });

            cancelButton.addActionListener(e -> confirmDialog.dispose());

            confirmDialog.setLocationRelativeTo(this);
            confirmDialog.setVisible(true);
        }
    }

    private void updateBalanceAfterRepayment(int amount) {
        try {
            File balanceFile = new File("accounts/" + username + "/balance.txt");
            if (balanceFile.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(balanceFile));
                String line = br.readLine();
                br.close();
                if (line != null && !line.isEmpty()) {
                    double current = Double.parseDouble(line);
                    current -= amount;
                    BufferedWriter bw = new BufferedWriter(new FileWriter(balanceFile));
                    bw.write(String.format("%.2f", current));
                    bw.close();
                }
            }
        } catch (Exception ignored) {}
    }

    private void setLoanPaid(String loanId) {
        ArrayList<String> all = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("loan_requests.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] s = line.split(";");
                if (s.length == 7 && s[0].equals(loanId)) {
                    all.add(s[0]+";"+s[1]+";"+s[2]+";"+s[3]+";"+s[4]+";"+s[5]+";PAID");
                } else {
                    all.add(line);
                }
            }
        } catch (Exception ignored) {}
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("loan_requests.txt"))) {
            for (String row : all) bw.write(row+"\n");
        } catch (Exception ignored) {}
    }

    private void showDetails() {
        if (selectedActive < 0 || activeLoans.size() <= selectedActive) return;
        Loan loan = activeLoans.get(selectedActive);
        JDialog dialog = new JDialog(this, "Loan Details", true);
        dialog.setSize(410, 350);
        dialog.setLayout(null);
        dialog.getContentPane().setBackground(new Color(30,32,48));
        JLabel l1 = new JLabel("Loan ID: "+loan.id);
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l1.setBounds(40,30,300,30);
        JLabel l2 = new JLabel("Type: "+loan.type);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l2.setBounds(40,65,300,30);
        JLabel l3 = new JLabel("Amount: £"+loan.amount);
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l3.setBounds(40,100,300,30);
        JLabel l4 = new JLabel("Monthly Rate: £"+loan.monthly);
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l4.setBounds(40,135,300,30);
        JLabel l5 = new JLabel("Status: "+loan.status);
        l5.setForeground(Color.WHITE);
        l5.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l5.setBounds(40,170,300,30);
        JLabel l6 = new JLabel("Next Payment: "+loan.nextPayment);
        l6.setForeground(Color.WHITE);
        l6.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l6.setBounds(40,205,300,30);
        JLabel l7 = new JLabel("Due Date: "+loan.due);
        l7.setForeground(Color.WHITE);
        l7.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        l7.setBounds(40,240,300,30);
        JButton history = new JButton("View Repayment History");
        history.setBackground(new Color(44,64,104));
        history.setForeground(Color.WHITE);
        history.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        history.setBounds(70, 280, 230, 30);
        history.addActionListener(e -> JOptionPane.showMessageDialog(this,"Repayment history for this loan is currently unavailable."));
        dialog.add(l1); dialog.add(l2); dialog.add(l3); dialog.add(l4); dialog.add(l5); dialog.add(l6); dialog.add(l7); dialog.add(history);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    static class Loan {
        String id;
        int amount;
        String type;
        int monthly;
        String nextPayment;
        String status;
        String due;

        Loan(String id, int amount, String type, int monthly, String nextPayment, String status, String due) {
            this.id = id;
            this.amount = amount;
            this.type = type;
            this.monthly = monthly;
            this.nextPayment = nextPayment;
            this.status = status;
            this.due = due;
        }
    }
}
