package com.virtualbank;

import com.formdev.flatlaf.FlatIntelliJLaf;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize Look and Feel");
        }

        SwingUtilities.invokeLater(() -> new HomeScreen().setVisible(true));
    }
}
