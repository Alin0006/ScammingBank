package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class InternationalPayments extends JFrame {

    public InternationalPayments() {
        setTitle("International Payment");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setUndecorated(true);
        getContentPane().setBackground(new Color(15, 22, 38));
        setLayout(null);

        JLabel title = new JLabel("International Payment");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        title.setBounds(150, 20, 300, 30);
        add(title);

        JTextField nameField = new JTextField();
        nameField.setBounds(150, 70, 200, 35);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addLabel("Beneficiary Name:", 30, 70);
        add(nameField);

        JTextField ibanField = new JTextField();
        ibanField.setBounds(150, 120, 200, 35);
        ibanField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addLabel("IBAN:", 30, 120);
        add(ibanField);

        JTextField swiftField = new JTextField();
        swiftField.setBounds(150, 170, 200, 35);
        swiftField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addLabel("SWIFT/BIC:", 30, 170);
        add(swiftField);

        JComboBox<String> countryBox = new JComboBox<>(new String[]{
                "Albania", "Andorra", "Armenia", "Austria", "Azerbaijan",
                "Belarus", "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia",
                "Cyprus", "Czech Republic", "Denmark", "Estonia", "Finland",
                "France", "Georgia", "Germany", "Greece", "Hungary",
                "Iceland", "Ireland", "Italy", "Kazakhstan", "Kosovo",
                "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta",
                "Moldova", "Monaco", "Montenegro", "Netherlands", "North Macedonia",
                "Norway", "Poland", "Portugal", "Romania", "Russia",
                "San Marino", "Serbia", "Slovakia", "Slovenia", "Spain",
                "Sweden", "Switzerland", "Turkey", "Ukraine", "United Kingdom", "Vatican City"
        });
        countryBox.setBounds(150, 220, 200, 35);
        countryBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addLabel("Country:", 30, 220);
        add(countryBox);

        JTextField amountField = new JTextField();
        amountField.setBounds(150, 270, 200, 35);
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addLabel("Amount (GBP):", 30, 270);
        add(amountField);

        JLabel feeLabel = new JLabel("Fee: £2.99");
        feeLabel.setBounds(150, 320, 200, 30);
        feeLabel.setForeground(new Color(180, 180, 180));
        feeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        add(feeLabel);

        JButton sendBtn = new JButton("Send");
        sendBtn.setBounds(185, 370, 120, 40);
        sendBtn.setBackground(new Color(32, 42, 68));
        sendBtn.setForeground(Color.WHITE);
        sendBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        sendBtn.setFocusPainted(false);
        add(sendBtn);

        JButton closeBtn = new JButton("X");
        closeBtn.setBounds(450, 10, 35, 30);
        closeBtn.setBackground(new Color(120, 0, 0));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setFocusPainted(false);
        add(closeBtn);

        sendBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String iban = ibanField.getText().trim();
            String swift = swiftField.getText().trim();
            String country = (String) countryBox.getSelectedItem();
            String amount = amountField.getText().trim();

            if (name.isEmpty() || iban.isEmpty() || swift.isEmpty() || amount.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Missing Info", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Payment sent to " + name + " (" + country + ").\nAmount: £" + amount + " + £2.99 fee.", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });

        closeBtn.addActionListener(e -> dispose());
    }

    private void addLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setBounds(x, y, 120, 30);
        add(label);
    }
}
