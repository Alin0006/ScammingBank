package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class LoanSuccessScreen extends JFrame {

    public LoanSuccessScreen() {
        setTitle("Application Submitted");
        setSize(420, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 245, 245));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel iconLabel = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/checkmark.png")).getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH)));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel successLabel = new JLabel("Your loan application was submitted.");
        successLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        successLabel.setForeground(new Color(30, 60, 90));
        successLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton okButton = new JButton("OK");
        okButton.setBackground(new Color(30, 60, 90));
        okButton.setForeground(Color.WHITE);
        okButton.setFocusPainted(false);
        okButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        okButton.setMaximumSize(new Dimension(120, 35));
        okButton.addActionListener(e -> dispose());

        panel.add(Box.createVerticalStrut(20));
        panel.add(iconLabel);
        panel.add(Box.createVerticalStrut(15));
        panel.add(successLabel);
        panel.add(Box.createVerticalStrut(20));
        panel.add(okButton);
        panel.add(Box.createVerticalStrut(20));

        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }
}
