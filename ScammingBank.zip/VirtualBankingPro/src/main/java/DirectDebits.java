package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.awt.image.BufferedImage;

public class DirectDebits extends JFrame {

    private JPanel listPanel;
    private String username;

    public DirectDebits(String username) {
        this.username = username;

        setTitle("Direct Debits");
        setSize(500, 550);
        setLocationRelativeTo(null);
        setUndecorated(true);
        getContentPane().setBackground(new Color(15, 22, 38));
        setLayout(null);

        JLabel title = new JLabel("Direct Debits");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        title.setBounds(180, 20, 200, 30);
        add(title);

        JButton closeBtn = new JButton("X");
        closeBtn.setBounds(450, 10, 35, 30);
        closeBtn.setBackground(new Color(120, 0, 0));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setFocusPainted(false);
        add(closeBtn);

        JButton addBtn = new JButton("Add New");
        addBtn.setBounds(180, 60, 140, 35);
        addBtn.setBackground(new Color(32, 42, 68));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        addBtn.setFocusPainted(false);
        add(addBtn);

        JLabel refreshIcon = new JLabel();
        refreshIcon.setBounds(330, 60, 32, 32);
        refreshIcon.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/refresh_icon1.png")).getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        refreshIcon.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(refreshIcon);

        listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(new Color(15, 22, 38));

        JScrollPane scrollPane = new JScrollPane(listPanel);
        scrollPane.setBounds(30, 110, 440, 400);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(10);
        add(scrollPane);

        loadDirectDebits();

        closeBtn.addActionListener(e -> dispose());

        addBtn.addActionListener(e -> {
            new AddDirectDebitWindow(username, this).setVisible(true);
        });

        refreshIcon.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                new Thread(() -> {
                    for (int i = 0; i <= 360; i += 10) {
                        final int angle = i;
                        SwingUtilities.invokeLater(() -> {
                            ImageIcon icon = new ImageIcon(getClass().getResource("/icons/refresh_icon1.png"));
                            Image rotated = ((ImageIcon) icon).getImage();
                            BufferedImage buffered = new BufferedImage(rotated.getWidth(null), rotated.getHeight(null), BufferedImage.TYPE_INT_ARGB);
                            Graphics2D g2d = buffered.createGraphics();
                            g2d.rotate(Math.toRadians(angle), buffered.getWidth() / 2, buffered.getHeight() / 2);
                            g2d.drawImage(rotated, 0, 0, null);
                            g2d.dispose();
                            refreshIcon.setIcon(new ImageIcon(buffered.getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
                        });
                        try {
                            Thread.sleep(5);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                    SwingUtilities.invokeLater(() -> reload());
                }).start();
            }
        });
    }

    private void loadDirectDebits() {
        File file = new File("directdebits_" + username + ".txt");
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 3) {
                    String name = parts[0];
                    String amount = parts[1];
                    String day = parts[2];
                    JPanel card = createCard(name, amount, day);
                    listPanel.add(card);
                    listPanel.add(Box.createVerticalStrut(10));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JPanel createCard(String name, String amount, String day) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(400, 60));
        panel.setMaximumSize(new Dimension(400, 60));
        panel.setBackground(new Color(32, 42, 68));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel label = new JLabel(name + "  –  £" + amount + " on day " + day);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(Color.WHITE);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setPreferredSize(new Dimension(80, 30));
        cancelBtn.setBackground(new Color(100, 0, 0));
        cancelBtn.setForeground(Color.WHITE);
        cancelBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cancelBtn.setFocusPainted(false);

        panel.add(label, BorderLayout.WEST);
        panel.add(cancelBtn, BorderLayout.EAST);

        cancelBtn.addActionListener(e -> {
            removeDirectDebit(name, amount, day);
            reload();
        });

        return panel;
    }

    private void saveDirectDebit(String name, String amount, String day) {
        try (FileWriter writer = new FileWriter("directdebits_" + username + ".txt", true)) {
            writer.write(name + ";" + amount + ";" + day + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void removeDirectDebit(String name, String amount, String day) {
        File file = new File("directdebits_" + username + ".txt");
        if (!file.exists()) return;
        File temp = new File("temp.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             BufferedWriter writer = new BufferedWriter(new FileWriter(temp))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.equals(name + ";" + amount + ";" + day)) {
                    writer.write(line + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        file.delete();
        temp.renameTo(file);
    }

    public void reload() {
        listPanel.removeAll();
        loadDirectDebits();
        listPanel.revalidate();
        listPanel.repaint();
    }
}
