package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class ThirdPartyScreen extends JFrame {

    public ThirdPartyScreen() {
        setTitle("Acknowledgements");
        setSize(450, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);
        Color textColor = Color.WHITE;

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundColor);

        JButton backButton = new JButton("←");
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(e -> dispose());

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(backgroundColor);
        topBar.add(backButton, BorderLayout.WEST);

        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(backgroundColor);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 20, 30));

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png"))
                .getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH)));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Acknowledgements");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        JTextArea textArea = new JTextArea();
        textArea.setText(
                "This application may use third-party visual resources, icons, or fonts made available under open-source licenses.\n\n"
                        + "All such materials remain the property of their respective authors and are used in compliance with applicable license terms.\n\n"
                        + "Notably:\n\n"
                        + "FlatLaf (Look and Feel): © FormDev Software, Apache License 2.0\n\n"
                        + "FontAwesome & Material Icons: © respective creators\n\n"
                        + "Any images or UI elements not created by the developer are used under free-use or open-source terms.\n\n"
                        + "No proprietary or paid third-party code is included in this application."
        );
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setEditable(false);
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textArea.setForeground(Color.WHITE);
        textArea.setBackground(backgroundColor);
        textArea.setCaretPosition(0);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(backgroundColor);
        scrollPane.setPreferredSize(new Dimension(380, 300));
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

        JLabel signature = new JLabel("© 2025 Alin Adrian Dragomir");
        signature.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        signature.setForeground(Color.LIGHT_GRAY);
        signature.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 0));
        signature.setHorizontalAlignment(SwingConstants.LEFT);

        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(backgroundColor);
        footerPanel.add(signature, BorderLayout.WEST);

        contentPanel.add(logo);
        contentPanel.add(title);
        contentPanel.add(scrollPane);

        mainPanel.add(topBar, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }
}
