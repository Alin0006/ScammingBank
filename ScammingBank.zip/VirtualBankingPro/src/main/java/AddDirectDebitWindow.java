package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

public class AddDirectDebitWindow extends JFrame {

    public AddDirectDebitWindow(String username, DirectDebits parent) {
        setTitle("New Direct Debit");
        setSize(420, 330);
        setUndecorated(true);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(15, 22, 38));
        setLayout(null);

        JLabel title = new JLabel("Add Direct Debit");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        title.setBounds(120, 20, 250, 30);
        add(title);

        JLabel nameLabel = new JLabel("Provider Name:");
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameLabel.setBounds(50, 70, 150, 25);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(180, 70, 180, 30);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        add(nameField);

        JLabel amountLabel = new JLabel("Amount (GBP):");
        amountLabel.setForeground(Color.WHITE);
        amountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        amountLabel.setBounds(50, 120, 150, 25);
        add(amountLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(180, 120, 180, 30);
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        add(amountField);

        JLabel dateLabel = new JLabel("Due Day (1–28):");
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateLabel.setBounds(50, 170, 150, 25);
        add(dateLabel);

        JTextField dayField = new JTextField();
        dayField.setBounds(180, 170, 180, 30);
        dayField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        add(dayField);

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(150, 230, 120, 40);
        addBtn.setBackground(new Color(32, 42, 68));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        addBtn.setFocusPainted(false);
        add(addBtn);

        JButton closeBtn = new JButton("X");
        closeBtn.setBounds(375, 10, 35, 30);
        closeBtn.setBackground(new Color(120, 0, 0));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setFocusPainted(false);
        add(closeBtn);

        closeBtn.addActionListener(e -> dispose());

        addBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String amount = amountField.getText().trim();
            String day = dayField.getText().trim();

            if (name.isEmpty() || amount.isEmpty() || day.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Missing Info", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (FileWriter writer = new FileWriter("directdebits_" + username + ".txt", true)) {
                writer.write(name + ";" + amount + ";" + day + "\n");
                dispose();
                parent.reload();
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving debit.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
