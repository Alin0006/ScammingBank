package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class LegalInfoScreen extends JFrame {

    public LegalInfoScreen() {
        setTitle("Legal Information");
        setSize(450, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);
        Color textColor = Color.WHITE;

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(backgroundColor);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png"))
                .getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH)));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Legal information");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        JLabel description = new JLabel("<html><div style='text-align: center;'>Important information about using the app, how we collect, protect and use your data, and our third party licenses.</div></html>");
        description.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        description.setForeground(textColor);
        description.setAlignmentX(Component.CENTER_ALIGNMENT);
        description.setMaximumSize(new Dimension(340, 60));

        JPanel btn1 = createRow("Legal and privacy");
        JPanel btn2 = createRow("Your data");
        JPanel btn3 = createRow("Third party acknowledgements");

        btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new LegalAndPrivacyScreen();
            }
        });

        btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new YourDataScreen();
            }
        });

        btn3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new ThirdPartyScreen();
            }
        });

        mainPanel.add(logo);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(title);
        mainPanel.add(description);
        mainPanel.add(Box.createVerticalStrut(30));
        mainPanel.add(btn1);
        mainPanel.add(Box.createVerticalStrut(12));
        mainPanel.add(btn2);
        mainPanel.add(Box.createVerticalStrut(12));
        mainPanel.add(btn3);

        add(mainPanel);
    }

    private JPanel createRow(String text) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setMaximumSize(new Dimension(340, 40));
        panel.setBackground(Color.WHITE);
        panel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));

        JLabel arrow = new JLabel("→");
        arrow.setFont(new Font("Segoe UI", Font.BOLD, 16));
        arrow.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        arrow.setForeground(Color.BLACK);

        panel.add(label, BorderLayout.WEST);
        panel.add(arrow, BorderLayout.EAST);

        return panel;
    }
}
