package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class LegalAndPrivacyScreen extends JFrame {

    public LegalAndPrivacyScreen() {
        setTitle("Legal and privacy");
        setSize(450, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color backgroundColor = new Color(30, 60, 90);
        Color textColor = Color.WHITE;

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(backgroundColor);

        JButton backButton = new JButton("←");
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(e -> dispose());

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(backgroundColor);
        topBar.add(backButton, BorderLayout.WEST);

        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(backgroundColor);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 20, 30));

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png"))
                .getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH)));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Legal and privacy");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        JTextArea textArea = new JTextArea();
        textArea.setText(
                "ScammingBank is a fully featured educational banking application, developed to simulate the core functionality of a real financial institution.\n"
                        + "It is not connected to any external system and does not interact with real banking infrastructure.\n\n"
                        + "All user data — including accounts, balances, credit cards, loans, and mortgages — is stored locally on your device.\n"
                        + "This data may be accessible to others only if you choose to share your project files.\n\n"
                        + "The app aims to replicate the full banking experience, including secure authentication, fund transfers, credit facilities, and financial operations — in an entirely offline environment, for academic and demonstrative use.\n\n"
                        + "Developed by Alin Adrian Dragomir");
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setEditable(false);
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textArea.setForeground(Color.WHITE);
        textArea.setBackground(backgroundColor);
        textArea.setCaretPosition(0);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(backgroundColor);
        scrollPane.setPreferredSize(new Dimension(380, 300));
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

        JLabel signature = new JLabel("© 2025 Alin Adrian Dragomir");
        signature.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        signature.setForeground(Color.LIGHT_GRAY);
        signature.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 0));
        signature.setHorizontalAlignment(SwingConstants.LEFT);

        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(backgroundColor);
        footerPanel.add(signature, BorderLayout.WEST);

        contentPanel.add(logo);
        contentPanel.add(title);
        contentPanel.add(scrollPane);

        mainPanel.add(topBar, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }
}
