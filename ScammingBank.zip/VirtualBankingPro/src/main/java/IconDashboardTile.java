package com.virtualbank.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class IconDashboardTile extends JPanel {

    private final JLabel iconLabel;
    private final JLabel titleLabel;

    public IconDashboardTile(String title, Icon icon, Color bgColor) {
        setPreferredSize(new Dimension(150, 130));
        setBackground(bgColor);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        setOpaque(false);

        iconLabel = new JLabel(icon);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        titleLabel.setForeground(new Color(30, 30, 30));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        add(iconLabel);
        add(titleLabel);

        addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createEmptyBorder(12, 12, 12, 12),
                        BorderFactory.createLineBorder(new Color(180, 180, 180), 2)
                ));
            }

            public void mouseExited(MouseEvent e) {
                setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        int arc = 20;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);

        g2.setColor(new Color(230, 230, 230));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);

        g2.dispose();
        super.paintComponent(g);
    }
}
