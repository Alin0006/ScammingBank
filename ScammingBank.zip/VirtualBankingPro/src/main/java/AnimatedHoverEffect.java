package com.virtualbank.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AnimatedHoverEffect extends JPanel {

    private float alpha = 0.0f;
    private Timer timer;
    private boolean hovering = false;

    public AnimatedHoverEffect(Color baseColor) {
        setBackground(baseColor);
        setOpaque(false);

        timer = new Timer(15, e -> {
            if (hovering && alpha < 0.3f) {
                alpha += 0.02f;
            } else if (!hovering && alpha > 0f) {
                alpha -= 0.02f;
            }
            repaint();
        });
        timer.start();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovering = true;
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovering = false;
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        int arc = 20;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);

        g2.setComposite(AlphaComposite.SrcOver.derive(alpha));
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);

        g2.dispose();
        super.paintComponent(g);
    }
}
