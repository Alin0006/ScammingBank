package com.virtualbank.ui;

import javax.swing.*;
import java.awt.*;

public class RegisterCard extends JPanel {

    public PlaceholderTextField usernameField;
    public PlaceholderTextField emailField;
    public PlaceholderPasswordField passwordField;
    public PlaceholderPasswordField confirmPasswordField;
    public JCheckBox termsCheckbox;
    public JButton registerButton;

    public RegisterCard() {
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(400, 380));
        setMaximumSize(new Dimension(400, 380));
        setBackground(new Color(255, 255, 255, 200));
        setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel title = new JLabel("Open a bank account");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        usernameField = new PlaceholderTextField("Username");
        emailField = new PlaceholderTextField("Email");
        passwordField = new PlaceholderPasswordField("Password");
        confirmPasswordField = new PlaceholderPasswordField("Confirm Password");

        JPanel userPanel = createInputWithIcon("/icons/user.png", usernameField);
        JPanel emailPanel = createInputWithIcon("/icons/email.png", emailField);
        JPanel passPanel = createInputWithIcon("/icons/lock.png", passwordField);
        JPanel confirmPanel = createInputWithIcon("/icons/confirm.png", confirmPasswordField);

        termsCheckbox = new JCheckBox("I accept the terms and conditions");
        termsCheckbox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        termsCheckbox.setAlignmentX(Component.CENTER_ALIGNMENT);
        termsCheckbox.setOpaque(false);

        registerButton = new JButton("Register");
        registerButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        registerButton.setBackground(Color.BLACK);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(title);
        add(Box.createVerticalStrut(20));
        add(userPanel);
        add(Box.createVerticalStrut(10));
        add(emailPanel);
        add(Box.createVerticalStrut(10));
        add(passPanel);
        add(Box.createVerticalStrut(10));
        add(confirmPanel);
        add(Box.createVerticalStrut(10));
        add(termsCheckbox);
        add(Box.createVerticalStrut(15));
        add(registerButton);
    }

    private JPanel createInputWithIcon(String iconPath, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 0));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));

        JLabel iconLabel = new JLabel(new ImageIcon(getClass().getResource(iconPath)));
        iconLabel.setPreferredSize(new Dimension(35, 35));
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);

        panel.add(iconLabel, BorderLayout.WEST);
        panel.add(field, BorderLayout.CENTER);

        return panel;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        int arc = 25;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
        g2.setColor(new Color(0, 0, 0, 25));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);

        g2.dispose();
        super.paintComponent(g);
    }
}
