package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.LinkedHashMap;

public class CryptoScreen extends JFrame {
    private LinkedHashMap<String, Double> cryptoPrices;
    private LinkedHashMap<String, Double> cryptoBalances;
    private String username;
    private double mainBalance;
    private JLabel balance;
    private JPanel gridPanel;
    private JScrollPane scrollPane;

    public CryptoScreen(String username, double mainBalance) {
        this.username = username;
        this.mainBalance = mainBalance;

        setTitle("Crypto Wallet");
        setSize(760, 600);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setLayout(null);
        getContentPane().setBackground(new Color(30, 35, 50));

        JLabel title = new JLabel("Crypto Wallet");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        title.setBounds(30, 20, 300, 30);
        add(title);

        balance = new JLabel("Available funds: £" + String.format("%.2f", mainBalance));
        balance.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        balance.setForeground(new Color(200, 200, 210));
        balance.setBounds(30, 60, 300, 25);
        add(balance);

        cryptoPrices = new LinkedHashMap<>();
        cryptoPrices.put("BTC", 25000.0);
        cryptoPrices.put("ETH", 1500.0);
        cryptoPrices.put("XRP", 0.5);
        cryptoPrices.put("ADA", 0.3);
        cryptoPrices.put("DOGE", 0.07);
        cryptoPrices.put("LTC", 90.0);
        cryptoPrices.put("SOL", 22.0);

        gridPanel = new JPanel(new GridLayout(0, 2, 20, 20));
        gridPanel.setBackground(new Color(30, 35, 50));
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        scrollPane = new JScrollPane(gridPanel);
        scrollPane.setBounds(30, 100, 700, 420);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(new Color(30, 35, 50));
        add(scrollPane);

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(600, 535, 120, 35);
        closeButton.setBackground(new Color(180, 40, 40));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeButton.addActionListener(e -> dispose());
        add(closeButton);

        updateAll();
        setVisible(true);
    }

    public void loadLatestData() {
        mainBalance = getLatestFiatBalance();
        loadCryptoBalances();
    }

    public void updateAll() {
        loadLatestData();
        updateFiatBalance();
        updateCryptoCards();
    }

    public void updateFiatBalance() {
        mainBalance = getLatestFiatBalance();
        balance.setText("Available funds: £" + String.format("%.2f", mainBalance));
    }

    public void updateCryptoCards() {
        gridPanel.removeAll();
        for (String symbol : cryptoPrices.keySet()) {
            double price = cryptoPrices.get(symbol);
            double balanceValue = cryptoBalances.getOrDefault(symbol, 0.0);
            JPanel card = createCryptoCard(symbol, price, balanceValue);
            card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            card.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    new CryptoTradeScreen(username, symbol, price, getLatestFiatBalance(), cryptoBalances.getOrDefault(symbol, 0.0), CryptoScreen.this);
                }
            });
            gridPanel.add(card);
        }
        gridPanel.revalidate();
        gridPanel.repaint();
    }

    private double getLatestFiatBalance() {
        File file = new File("users.txt");
        if (!file.exists()) return mainBalance;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 4 && parts[0].equals(username)) {
                    return Double.parseDouble(parts[3].trim().replace(",", ""));
                }
            }
        } catch (Exception e) {
        }
        return mainBalance;
    }

    private void loadCryptoBalances() {
        cryptoBalances = new LinkedHashMap<>();
        for (String key : cryptoPrices.keySet()) {
            cryptoBalances.put(key, 0.0);
        }
        File file = new File("crypto_balances.txt");
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(username + " |")) {
                    String[] parts = line.split("\\|");
                    for (String part : parts) {
                        part = part.trim();
                        if (part.contains("=")) {
                            String[] kv = part.split("=");
                            if (kv.length == 2) {
                                String symbol = kv[0].trim();
                                double value = Double.parseDouble(kv[1].trim().replace(",", ""));
                                cryptoBalances.put(symbol, value);
                            }
                        }
                    }
                    break;
                }
            }
        } catch (IOException | NumberFormatException e) {
        }
    }

    private JPanel createCryptoCard(String symbol, double price, double balance) {
        JPanel panel = new RoundedPanel(18, new Color(40, 46, 70));
        panel.setLayout(new BorderLayout());
        panel.setPreferredSize(new Dimension(320, 100));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel iconCircle = new RoundedPanel(24, new Color(60, 70, 100));
        iconCircle.setPreferredSize(new Dimension(48, 48));
        iconCircle.setLayout(new BorderLayout());

        JLabel initials = new JLabel(symbol);
        initials.setFont(new Font("Segoe UI", Font.BOLD, 16));
        initials.setForeground(Color.WHITE);
        initials.setHorizontalAlignment(SwingConstants.CENTER);
        initials.setVerticalAlignment(SwingConstants.CENTER);
        iconCircle.add(initials, BorderLayout.CENTER);

        JPanel centerPanel = new JPanel(new GridLayout(3, 1));
        centerPanel.setBackground(new Color(0, 0, 0, 0));

        JLabel nameLabel = new JLabel(symbol, SwingConstants.CENTER);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        nameLabel.setForeground(Color.WHITE);

        JLabel priceLabel = new JLabel("£" + String.format("%.2f", price), SwingConstants.CENTER);
        priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        priceLabel.setForeground(new Color(150, 160, 180));

        JLabel balanceLabel = new JLabel(String.format("%.4f", balance) + " " + symbol, SwingConstants.CENTER);
        balanceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        balanceLabel.setForeground(new Color(110, 230, 150));

        centerPanel.add(nameLabel);
        centerPanel.add(priceLabel);
        centerPanel.add(balanceLabel);

        panel.add(iconCircle, BorderLayout.WEST);
        panel.add(centerPanel, BorderLayout.CENTER);

        return panel;
    }

    private static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color background;

        public RoundedPanel(int radius, Color bg) {
            this.radius = radius;
            this.background = bg;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(background);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            super.paintComponent(g);
        }
    }
}
