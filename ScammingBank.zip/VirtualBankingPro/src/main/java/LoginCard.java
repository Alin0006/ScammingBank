package com.virtualbank.ui;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginCard extends JPanel {

    public JTextField usernameField;
    public JPasswordField passwordField;
    public JButton loginButton;

    public LoginCard() {
        setLayout(null);
        setBackground(new Color(220, 225, 230));
        setBounds(100, 80, 400, 300);

        JLabel title = new JLabel("Login to your account");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setBounds(100, 10, 250, 30);
        add(title);

        usernameField = createTextField("Username");
        usernameField.setBounds(70, 60, 250, 35);
        add(usernameField);

        JLabel userIcon = new JLabel(new ImageIcon(getClass().getResource("/icons/user.png")));
        userIcon.setBounds(30, 60, 32, 32);
        add(userIcon);

        passwordField = new JPasswordField();
        passwordField.setText("Password");
        passwordField.setForeground(Color.GRAY);
        passwordField.setBounds(70, 110, 250, 35);
        passwordField.setEchoChar((char) 0);
        add(passwordField);

        JLabel lockIcon = new JLabel(new ImageIcon(getClass().getResource("/icons/lock.png")));
        lockIcon.setBounds(30, 110, 32, 32);
        add(lockIcon);

        JLabel eyeIcon = new JLabel(new ImageIcon(getClass().getResource("/icons/eye.png")));
        eyeIcon.setBounds(295, 116, 24, 24); 
        eyeIcon.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        add(eyeIcon);
        setComponentZOrder(eyeIcon, 0);

        eyeIcon.addMouseListener(new MouseAdapter() {
            private boolean visible = false;
            public void mouseClicked(MouseEvent e) {
                visible = !visible;
                if (visible) {
                    passwordField.setEchoChar((char) 0);
                } else {
                    if (!passwordField.getText().equals("Password")) {
                        passwordField.setEchoChar('•');
                    }
                }
            }
        });

        addPlaceholderBehavior(usernameField, "Username");
        addPlaceholderBehavior(passwordField, "Password");

        loginButton = new JButton("Login");
        loginButton.setBounds(70, 170, 250, 40);
        loginButton.setBackground(Color.BLACK);
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        add(loginButton);
    }

    private JTextField createTextField(String placeholder) {
        JTextField field = new JTextField();
        field.setText(placeholder);
        field.setForeground(Color.GRAY);
        return field;
    }

    private void addPlaceholderBehavior(JTextComponent field, String placeholder) {
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                    if (field instanceof JPasswordField) {
                        ((JPasswordField) field).setEchoChar('•');
                    }
                }
            }

            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(Color.GRAY);
                    if (field instanceof JPasswordField) {
                        ((JPasswordField) field).setEchoChar((char) 0);
                    }
                }
            }
        });
    }
}
