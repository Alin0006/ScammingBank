package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import screens.MortgageServicesScreen;

public class FinancialServicesScreen extends JFrame {

    private String username;

    public FinancialServicesScreen(String username) {
        this.username = username;
        setTitle("Financial Services");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color bg = new Color(20, 25, 45);
        Color cardColor = new Color(35, 40, 60);
        Color textColor = Color.WHITE;

        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(bg);
        JLabel title = new JLabel("Financial Services");
        title.setForeground(textColor);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titlePanel.add(title);
        add(titlePanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel(new GridLayout(2, 2, 30, 30));
        contentPanel.setBackground(bg);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));

        contentPanel.add(createServiceCard("Credit Card", cardColor, textColor));
        contentPanel.add(createServiceCard("Loan", cardColor, textColor));
        contentPanel.add(createServiceCard("Mortgage", cardColor, textColor));
        contentPanel.add(createServiceCard("Overdraft", cardColor, textColor));

        add(contentPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private JPanel createServiceCard(String title, Color bgColor, Color textColor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bgColor);
        panel.setPreferredSize(new Dimension(180, 120));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 70, 90)),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel label = new JLabel(title, SwingConstants.CENTER);
        label.setForeground(textColor);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        panel.add(label, BorderLayout.CENTER);

        panel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                panel.setBackground(bgColor.brighter());
            }
            public void mouseExited(MouseEvent e) {
                panel.setBackground(bgColor);
            }
            public void mouseClicked(MouseEvent e) {
                switch (title) {
                    case "Credit Card": new CreditCardScreen(); break;
                    case "Loan": new LoanServicesScreen(); break;
                    case "Mortgage": new MortgageServicesScreen(username); break;
                    case "Overdraft": new OverdraftServicesScreen(username); break;
                }
            }
        });

        return panel;
    }
}
