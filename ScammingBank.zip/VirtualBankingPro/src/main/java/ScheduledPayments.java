package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.image.BufferedImage;

public class ScheduledPayments extends JFrame {

    private JPanel listPanel;
    private String username;

    public ScheduledPayments(String username) {
        this.username = username;

        setTitle("Scheduled Payments");
        setSize(360, 400);
        setLocationRelativeTo(null);
        setUndecorated(true);
        getContentPane().setBackground(new Color(15, 22, 38));
        setLayout(null);

        JLabel logo = new JLabel();
        logo.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH)));
        logo.setBounds(145, 5, 70, 70);
        add(logo);

        JLabel title = new JLabel("Scheduled Payments");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        title.setBounds(60, 70, 240, 30);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title);

        JButton closeBtn = new JButton("X");
        closeBtn.setBounds(310, 10, 35, 30);
        closeBtn.setBackground(new Color(120, 0, 0));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setFocusPainted(false);
        add(closeBtn);

        JButton addBtn = new JButton("Add Scheduled Payment");
        addBtn.setBounds(60, 110, 240, 35);
        addBtn.setBackground(new Color(32, 42, 68));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        addBtn.setFocusPainted(false);
        add(addBtn);

        JLabel refreshIcon = new JLabel();
        refreshIcon.setBounds(305, 112, 32, 32);
        refreshIcon.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/refresh_icon1.png")).getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        refreshIcon.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(refreshIcon);

        listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBackground(new Color(15, 22, 38));

        JScrollPane scrollPane = new JScrollPane(listPanel);
        scrollPane.setBounds(20, 160, 320, 220);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(10);
        add(scrollPane);

        loadScheduledPayments();

        closeBtn.addActionListener(e -> dispose());

        addBtn.addActionListener(e -> {
            JDialog dialog = new JDialog();
            dialog.setSize(360, 250);
            dialog.setLocationRelativeTo(this);
            dialog.setUndecorated(true);
            dialog.setLayout(null);
            dialog.getContentPane().setBackground(new Color(25, 32, 48));

            JLabel nameLabel = new JLabel("Recipient Name:");
            nameLabel.setBounds(30, 20, 300, 20);
            nameLabel.setForeground(Color.WHITE);
            JTextField nameField = new JTextField();
            nameField.setBounds(30, 40, 300, 30);

            JLabel amountLabel = new JLabel("Amount (GBP):");
            amountLabel.setBounds(30, 75, 300, 20);
            amountLabel.setForeground(Color.WHITE);
            JTextField amountField = new JTextField();
            amountField.setBounds(30, 95, 300, 30);

            JLabel dayLabel = new JLabel("Payment Day (1–28):");
            dayLabel.setBounds(30, 130, 300, 20);
            dayLabel.setForeground(Color.WHITE);
            JTextField dayField = new JTextField();
            dayField.setBounds(30, 150, 300, 30);

            JButton okBtn = new JButton("OK");
            okBtn.setBounds(70, 190, 90, 30);
            okBtn.setBackground(new Color(30, 144, 255));
            okBtn.setForeground(Color.WHITE);
            okBtn.setFocusPainted(false);

            JButton cancelBtn = new JButton("Cancel");
            cancelBtn.setBounds(190, 190, 90, 30);
            cancelBtn.setBackground(new Color(100, 100, 100));
            cancelBtn.setForeground(Color.WHITE);
            cancelBtn.setFocusPainted(false);

            dialog.add(nameLabel);
            dialog.add(nameField);
            dialog.add(amountLabel);
            dialog.add(amountField);
            dialog.add(dayLabel);
            dialog.add(dayField);
            dialog.add(okBtn);
            dialog.add(cancelBtn);

            okBtn.addActionListener(ev -> {
                String name = nameField.getText().trim();
                String amount = amountField.getText().trim();
                String day = dayField.getText().trim();

                if (!name.isEmpty() && !amount.isEmpty() && !day.isEmpty()) {
                    saveScheduledPayment(name, amount, day);
                    dialog.dispose();
                    reload();
                } else {
                    JOptionPane.showMessageDialog(dialog, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            cancelBtn.addActionListener(ev -> dialog.dispose());
            dialog.setVisible(true);
        });

        refreshIcon.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                new Thread(() -> {
                    for (int i = 0; i <= 360; i += 10) {
                        final int angle = i;
                        SwingUtilities.invokeLater(() -> {
                            ImageIcon icon = new ImageIcon(getClass().getResource("/icons/refresh_icon1.png"));
                            Image rotated = icon.getImage();
                            BufferedImage buffered = new BufferedImage(rotated.getWidth(null), rotated.getHeight(null), BufferedImage.TYPE_INT_ARGB);
                            Graphics2D g2d = buffered.createGraphics();
                            g2d.rotate(Math.toRadians(angle), buffered.getWidth() / 2, buffered.getHeight() / 2);
                            g2d.drawImage(rotated, 0, 0, null);
                            g2d.dispose();
                            refreshIcon.setIcon(new ImageIcon(buffered.getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
                        });
                        try {
                            Thread.sleep(5);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                    SwingUtilities.invokeLater(() -> reload());
                }).start();
            }
        });
    }

    private void loadScheduledPayments() {
        File file = new File("scheduledpayments_" + username + ".txt");
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 3) {
                    String name = parts[0];
                    String amount = parts[1];
                    String day = parts[2];
                    JPanel card = createCard(name, amount, day);
                    listPanel.add(card);
                    listPanel.add(Box.createVerticalStrut(10));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JPanel createCard(String name, String amount, String day) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(300, 55));
        panel.setMaximumSize(new Dimension(300, 55));
        panel.setBackground(new Color(32, 42, 68));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel label = new JLabel(name + "  –  £" + amount + " on day " + day);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setForeground(Color.WHITE);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setPreferredSize(new Dimension(80, 30));
        cancelBtn.setBackground(new Color(100, 0, 0));
        cancelBtn.setForeground(Color.WHITE);
        cancelBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cancelBtn.setFocusPainted(false);

        panel.add(label, BorderLayout.WEST);
        panel.add(cancelBtn, BorderLayout.EAST);

        cancelBtn.addActionListener(e -> {
            removeScheduledPayment(name, amount, day);
            reload();
        });

        return panel;
    }

    private void saveScheduledPayment(String name, String amount, String day) {
        try (FileWriter writer = new FileWriter("scheduledpayments_" + username + ".txt", true)) {
            writer.write(name + ";" + amount + ";" + day + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void removeScheduledPayment(String name, String amount, String day) {
        File file = new File("scheduledpayments_" + username + ".txt");
        if (!file.exists()) return;
        File temp = new File("temp.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             BufferedWriter writer = new BufferedWriter(new FileWriter(temp))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.equals(name + ";" + amount + ";" + day)) {
                    writer.write(line + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        file.delete();
        temp.renameTo(file);
    }

    public void reload() {
        listPanel.removeAll();
        loadScheduledPayments();
        listPanel.revalidate();
        listPanel.repaint();
    }
}
