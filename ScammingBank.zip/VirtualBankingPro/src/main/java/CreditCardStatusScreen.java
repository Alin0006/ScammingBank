package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class CreditCardStatusScreen extends JFrame {
    private String currentUser;
    private JLabel statusLabel;

    public CreditCardStatusScreen(String username) {
        this.currentUser = username;
        setTitle("Credit Card Application Status");
        setSize(450, 300);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(20, 20, 20));

        JLabel titleLabel = new JLabel("Credit Card Application Status");
        titleLabel.setBounds(50, 30, 350, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        statusLabel = new JLabel();
        statusLabel.setBounds(50, 100, 350, 30);
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        statusLabel.setForeground(Color.GREEN);
        add(statusLabel);

        String status = getStatusForUser(currentUser);
        if (status == null) {
            statusLabel.setText("No credit card currently active.");
        } else {
            statusLabel.setText("Status: " + status);
        }

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(150, 180, 120, 30);
        closeButton.setBackground(new Color(0, 120, 255));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        add(closeButton);

        closeButton.addActionListener(e -> dispose());

        setVisible(true);
    }

    private String getStatusForUser(String user) {
        File file = new File("credit_card_requests.txt");
        if (!file.exists()) return null;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            String lastStatus = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(user + "|")) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 10) {
                        lastStatus = parts[9];
                    }
                }
            }
            return lastStatus;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
