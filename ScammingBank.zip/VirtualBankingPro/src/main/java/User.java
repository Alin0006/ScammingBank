package com.virtualbank;

public class User {
    private String username;
    private String email;
    private String password;
    private double balance;
    private String status;
    private String language;
    private boolean darkMode;

    public User(String username, String email, String password, double balance, String status, String language, boolean darkMode) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.balance = balance;
        this.status = status;
        this.language = language;
        this.darkMode = darkMode;
    }

    public User(String username, String email, String password, double balance, String status) {
        this(username, email, password, balance, status, "English", false);
    }

    public User(String username, String email, String password, double balance) {
        this(username, email, password, balance, "active", "English", false);
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public boolean isDarkMode() {
        return darkMode;
    }

    public void setDarkMode(boolean darkMode) {
        this.darkMode = darkMode;
    }
}
