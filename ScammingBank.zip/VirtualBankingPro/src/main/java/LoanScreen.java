package com.virtualbank;

import javax.swing.*;
import java.awt.*;

public class LoanScreen extends JFrame {

    public LoanScreen() {
        setTitle("Loan Services");
        setSize(550, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color bg = new Color(20, 25, 45);
        Color textColor = Color.WHITE;

        JPanel header = new JPanel();
        header.setBackground(bg);
        JLabel title = new JLabel("Loan Services");
        title.setForeground(textColor);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.add(title);
        add(header, BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setBackground(bg);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        JLabel text = new JLabel("Manage your loans, apply or repay.");
        text.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        text.setForeground(textColor);
        text.setAlignmentX(Component.CENTER_ALIGNMENT);

        content.add(text);
        add(content, BorderLayout.CENTER);

        setVisible(true);
    }
}
