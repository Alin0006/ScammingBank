package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HelpScreen extends JFrame {

    private final String username;

    public HelpScreen(String username) {
        this.username = username;
        setTitle("Help & Support");
        setSize(550, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color bgColor = new Color(30, 35, 50);
        Color textColor = Color.WHITE;

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(bgColor);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH)));
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0));

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(bgColor);
        tabs.setForeground(Color.WHITE);
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        tabs.add("Send Request", buildSendPanel());
        tabs.add("Request History", buildHistoryPanel());
        tabs.add("FAQ", buildFAQPanel());
        tabs.add("Contact", buildContactPanel());

        mainPanel.add(logo, BorderLayout.NORTH);
        mainPanel.add(tabs, BorderLayout.CENTER);
        add(mainPanel);
    }

    private JPanel buildSendPanel() {
        Color bg = new Color(30, 35, 50);
        JPanel panel = new JPanel();
        panel.setBackground(bg);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String[] issues = {"Account Blocked", "Transfer Error", "Login Issue", "Other"};
        JComboBox<String> issueType = new JComboBox<>(issues);
        issueType.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        issueType.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JTextArea messageField = new JTextArea();
        messageField.setLineWrap(true);
        messageField.setWrapStyleWord(true);
        messageField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        messageField.setBackground(new Color(45, 50, 70));
        messageField.setForeground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(messageField);
        scroll.setPreferredSize(new Dimension(400, 150));

        JButton sendBtn = new JButton("Send Request");
        sendBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        sendBtn.setBackground(new Color(0, 120, 215));
        sendBtn.setForeground(Color.WHITE);
        sendBtn.setFocusPainted(false);

        JLabel status = new JLabel(" ");
        status.setForeground(Color.LIGHT_GRAY);
        status.setAlignmentX(Component.CENTER_ALIGNMENT);

        sendBtn.addActionListener((ActionEvent e) -> {
            String type = (String) issueType.getSelectedItem();
            String message = messageField.getText().trim();
            if (message.isEmpty()) {
                status.setText("Please enter your message.");
                return;
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("support_requests.txt", true))) {
                writer.write(username + " | " + type + " | " + message);
                writer.newLine();
                status.setText("Request sent successfully.");
                messageField.setText("");
            } catch (IOException ex) {
                status.setText("Error while sending request.");
            }
        });

        panel.add(new JLabel("Select Issue Type:"));
        panel.add(Box.createVerticalStrut(5));
        panel.add(issueType);
        panel.add(Box.createVerticalStrut(15));
        panel.add(new JLabel("Describe your issue:"));
        panel.add(scroll);
        panel.add(Box.createVerticalStrut(15));
        panel.add(sendBtn);
        panel.add(Box.createVerticalStrut(10));
        panel.add(status);

        return panel;
    }

    private JPanel buildHistoryPanel() {
        Color bg = new Color(30, 35, 50);
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bg);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        DefaultListModel<String> model = new DefaultListModel<>();
        File file = new File("support_requests.txt");
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith(username + " |")) {
                        model.addElement(line);
                    }
                }
            } catch (IOException ignored) {}
        }

        JList<String> list = new JList<>(model);
        list.setBackground(new Color(45, 50, 70));
        list.setForeground(Color.WHITE);
        list.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(list);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildFAQPanel() {
        Color bg = new Color(30, 35, 50);
        Color fg = Color.WHITE;
        JPanel panel = new JPanel();
        panel.setBackground(bg);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        String[][] faq = {
                {"Why is my account blocked?", "Your account may be blocked due to suspicious activity or multiple failed login attempts."},
                {"How can I transfer money?", "Go to the dashboard and click the Transfer button to initiate a transaction."},
                {"What if I entered the wrong recipient?", "Contact support immediately via Help > Send Request."},
                {"Can I recover a deleted account?", "Currently, deleted accounts are not recoverable. Please register a new one."}
        };

        for (String[] qa : faq) {
            JLabel q = new JLabel("Q: " + qa[0]);
            q.setFont(new Font("Segoe UI", Font.BOLD, 13));
            q.setForeground(fg);
            JLabel a = new JLabel("<html><body style='width: 400px;'>A: " + qa[1] + "</body></html>");
            a.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            a.setForeground(Color.LIGHT_GRAY);
            panel.add(q);
            panel.add(a);
            panel.add(Box.createVerticalStrut(15));
        }

        return panel;
    }

    private JPanel buildContactPanel() {
        Color bg = new Color(30, 35, 50);
        Color fg = Color.WHITE;
        JPanel panel = new JPanel();
        panel.setBackground(bg);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        JLabel email = new JLabel("Email: support@scammingbank.co.uk");
        email.setForeground(fg);
        email.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JLabel phone = new JLabel("Phone: +44 123 456 7890");
        phone.setForeground(fg);
        phone.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JLabel hours = new JLabel("Support Hours: Mon - Fri, 09:00 - 17:00");
        hours.setForeground(fg);
        hours.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        panel.add(email);
        panel.add(Box.createVerticalStrut(10));
        panel.add(phone);
        panel.add(Box.createVerticalStrut(10));
        panel.add(hours);

        return panel;
    }
}
