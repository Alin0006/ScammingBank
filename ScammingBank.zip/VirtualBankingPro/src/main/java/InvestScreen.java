package com.virtualbank;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class InvestScreen extends JFrame {

    private final String username;
    private final JTable marketTable;
    private final JTable portfolioTable;
    private final DefaultTableModel marketModel;
    private final DefaultTableModel portfolioModel;
    private final JTextField qtyField;
    private final JLabel selectedTickerLabel;
    private final JLabel selectedPriceLabel;
    private final JLabel subtotalLabel;
    private final JLabel balanceLabel;

    public InvestScreen(String username) {
        this.username = username;
        setTitle("Invest");
        setSize(900, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        marketModel = new DefaultTableModel(new Object[]{"Ticker", "Name", "Price", "Change"}, 0);
        portfolioModel = new DefaultTableModel(new Object[]{"Ticker", "Quantity", "Avg. Price", "Current Value", "P/L"}, 0);

        marketTable = new JTable(marketModel);
        portfolioTable = new JTable(portfolioModel);
        qtyField = new JTextField();
        selectedTickerLabel = new JLabel();
        selectedPriceLabel = new JLabel();
        subtotalLabel = new JLabel();
        balanceLabel = new JLabel();

        initUI();
        loadMarketData();
        loadPortfolio();
        updateBalanceLabel();
        setVisible(true);
    }

    private void initUI() {
        Color bg = new Color(30, 35, 50);
        Color fg = Color.WHITE;
        getContentPane().setBackground(bg);
        getContentPane().setLayout(new BorderLayout(10, 10));

        marketTable.setRowHeight(30);
        portfolioTable.setRowHeight(30);
        marketTable.getTableHeader().setReorderingAllowed(false);
        portfolioTable.getTableHeader().setReorderingAllowed(false);
        marketTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        portfolioTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane marketScroll = new JScrollPane(marketTable);
        JScrollPane portfolioScroll = new JScrollPane(portfolioTable);

        JPanel tradePanel = new JPanel();
        tradePanel.setBackground(bg);
        tradePanel.setLayout(new BoxLayout(tradePanel, BoxLayout.Y_AXIS));

        selectedTickerLabel.setForeground(fg);
        selectedTickerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        selectedPriceLabel.setForeground(fg);
        selectedPriceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        subtotalLabel.setForeground(fg);
        subtotalLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        balanceLabel.setForeground(fg);
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));

        qtyField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JButton buyButton = new JButton("Buy");
        JButton sellButton = new JButton("Sell");

        buyButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        sellButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        qtyField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { updateSubtotal(); }
            public void removeUpdate(DocumentEvent e) { updateSubtotal(); }
            public void changedUpdate(DocumentEvent e) { updateSubtotal(); }
        });

        buyButton.addActionListener(e -> performTrade("Buy"));
        sellButton.addActionListener(e -> performTrade("Sell"));

        tradePanel.add(Box.createVerticalStrut(20));
        tradePanel.add(balanceLabel);
        tradePanel.add(Box.createVerticalStrut(20));
        tradePanel.add(selectedTickerLabel);
        tradePanel.add(Box.createVerticalStrut(10));
        tradePanel.add(selectedPriceLabel);
        tradePanel.add(Box.createVerticalStrut(10));
        tradePanel.add(subtotalLabel);
        tradePanel.add(Box.createVerticalStrut(20));
        tradePanel.add(new JLabel("Quantity") {{ setForeground(fg); setFont(new Font("Segoe UI", Font.PLAIN, 14)); }});
        tradePanel.add(qtyField);
        tradePanel.add(Box.createVerticalStrut(20));
        tradePanel.add(buyButton);
        tradePanel.add(Box.createVerticalStrut(10));
        tradePanel.add(sellButton);

        marketTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && marketTable.getSelectedRow() != -1) {
                String ticker = marketTable.getValueAt(marketTable.getSelectedRow(), 0).toString();
                String price = marketTable.getValueAt(marketTable.getSelectedRow(), 2).toString();
                selectedTickerLabel.setText(ticker);
                selectedPriceLabel.setText(price);
                updateSubtotal();
            }
        });

        portfolioTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && portfolioTable.getSelectedRow() != -1) {
                String ticker = portfolioTable.getValueAt(portfolioTable.getSelectedRow(), 0).toString();
                String price = findMarketPrice(ticker);
                selectedTickerLabel.setText(ticker);
                selectedPriceLabel.setText(price);
                updateSubtotal();
            }
        });

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, marketScroll, tradePanel);
        splitPane.setResizeWeight(0.7);

        JPanel marketPanel = new JPanel(new BorderLayout());
        marketPanel.setBackground(bg);
        marketPanel.add(new JLabel(" Market Watch") {{ setForeground(fg); setFont(new Font("Segoe UI", Font.BOLD, 20)); }}, BorderLayout.NORTH);
        marketPanel.add(splitPane, BorderLayout.CENTER);

        JPanel portfolioPanel = new JPanel(new BorderLayout());
        portfolioPanel.setBackground(bg);
        portfolioPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        portfolioPanel.add(new JLabel(" My Portfolio") {{ setForeground(fg); setFont(new Font("Segoe UI", Font.BOLD, 20)); }}, BorderLayout.NORTH);
        portfolioPanel.add(portfolioScroll, BorderLayout.CENTER);
        portfolioPanel.setPreferredSize(new Dimension(0, 200));

        getContentPane().add(marketPanel, BorderLayout.CENTER);
        getContentPane().add(portfolioPanel, BorderLayout.SOUTH);
    }

    private void updateSubtotal() {
        if (selectedPriceLabel.getText().isEmpty()) return;
        try {
            double price = Double.parseDouble(selectedPriceLabel.getText().replace("£", ""));
            int qty = Integer.parseInt(qtyField.getText());
            subtotalLabel.setText("Subtotal: £" + String.format("%.2f", price * qty));
        } catch (Exception e) {
            subtotalLabel.setText("");
        }
    }

    private void loadMarketData() {
        marketModel.addRow(new Object[]{"AAPL", "Apple Inc.", "£142.35", "+1.2%"});
        marketModel.addRow(new Object[]{"TSLA", "Tesla Inc.", "£620.10", "-0.8%"});
        marketModel.addRow(new Object[]{"AMZN", "Amazon.com", "£103.50", "+0.5%"});
        marketModel.addRow(new Object[]{"GOOGL", "Alphabet Inc.", "£115.20", "+0.9%"});
        marketModel.addRow(new Object[]{"MSFT", "Microsoft Corp.", "£250.75", "+0.3%"});
        marketModel.addRow(new Object[]{"NFLX", "Netflix Inc.", "£320.40", "-0.4%"});
    }

    private void loadPortfolio() {
        portfolioModel.setRowCount(0);
        File file = new File(username + "_portfolio.txt");
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split(",");
                String t = p[0];
                int q = Integer.parseInt(p[1]);
                double avg = Double.parseDouble(p[2]);
                double current = q * Double.parseDouble(findMarketPrice(t));
                double pl = current - q * avg;
                portfolioModel.addRow(new Object[]{t, q, String.format("£%.2f", avg), String.format("£%.2f", current), String.format("£%.2f", pl)});
            }
        } catch (Exception ignored) {}
    }

    private String findMarketPrice(String ticker) {
        for (int i = 0; i < marketModel.getRowCount(); i++) {
            if (marketModel.getValueAt(i, 0).equals(ticker)) {
                return marketModel.getValueAt(i, 2).toString().replace("£", "");
            }
        }
        return "0";
    }

    private void performTrade(String action) {
        if (selectedTickerLabel.getText().isEmpty()) return;
        String ticker = selectedTickerLabel.getText();
        int qty;
        try {
            qty = Integer.parseInt(qtyField.getText());
        } catch (Exception e) {
            return;
        }
        double price = Double.parseDouble(selectedPriceLabel.getText().replace("£", ""));
        double total = price * qty;
        UserService us = new UserService();
        User u = us.loadUser(username);
        if (u == null) return;
        if (action.equals("Buy")) {
            if (u.getBalance() < total) {
                JOptionPane.showMessageDialog(this, "Insufficient balance.");
                return;
            }
            u.setBalance(u.getBalance() - total);
            updateUserBalanceFile(u);
            recordTransaction(username + " -> Invest", total);
            updatePortfolioFile(ticker, qty, price);
        } else {
            int row = portfolioTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select a stock from your portfolio to sell.");
                return;
            }
            String selectedTicker = portfolioModel.getValueAt(row, 0).toString();
            if (!selectedTicker.equals(ticker)) {
                JOptionPane.showMessageDialog(this, "Selected ticker doesn't match.");
                return;
            }
            int owned = Integer.parseInt(portfolioModel.getValueAt(row, 1).toString());
            if (qty > owned) {
                JOptionPane.showMessageDialog(this, "Not enough shares to sell.");
                return;
            }
            u.setBalance(u.getBalance() + total);
            updateUserBalanceFile(u);
            recordTransaction("Invest -> " + username, total);
            updatePortfolioFile(ticker, -qty, price);
        }
        qtyField.setText("");
        updateBalanceLabel();
        loadPortfolio();
        Dashboard.refreshBalanceExtern(username);
    }

    private void updateUserBalanceFile(User u) {
        File file = new File("users.txt");
        if (!file.exists()) return;
        java.util.List<String> lines = new java.util.ArrayList<>();
        try (BufferedReader r = new BufferedReader(new FileReader(file))) {
            String l;
            while ((l = r.readLine()) != null) {
                String[] p = l.split(";");
                if (p.length >= 5 && p[0].equals(u.getUsername())) {
                    lines.add(p[0] + ";" + p[1] + ";" + p[2] + ";" + u.getBalance() + ";" + p[4]);
                } else {
                    lines.add(l);
                }
            }
        } catch (Exception ignored) {}
        try (PrintWriter w = new PrintWriter(new FileWriter(file))) {
            for (String ln : lines) w.println(ln);
        } catch (Exception ignored) {}
    }

    private void updateBalanceLabel() {
        UserService us = new UserService();
        User u = us.loadUser(username);
        if (u != null) {
            balanceLabel.setText("Balance: £" + String.format("%.2f", u.getBalance()));
        }
    }

    private void updatePortfolioFile(String ticker, int qtyChange, double price) {
        Map<String, String[]> map = new LinkedHashMap<>();
        File file = new File(username + "_portfolio.txt");
        if (file.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(file))) {
                String l;
                while ((l = r.readLine()) != null) {
                    String[] p = l.split(",");
                    map.put(p[0], new String[]{p[1], p[2]});
                }
            } catch (Exception ignored) {}
        }
        if (qtyChange > 0) {
            if (map.containsKey(ticker)) {
                int oldQ = Integer.parseInt(map.get(ticker)[0]);
                double oldAvg = Double.parseDouble(map.get(ticker)[1]);
                int newQ = oldQ + qtyChange;
                double newAvg = (oldAvg * oldQ + price * qtyChange) / newQ;
                map.put(ticker, new String[]{String.valueOf(newQ), String.valueOf(newAvg)});
            } else {
                map.put(ticker, new String[]{String.valueOf(qtyChange), String.valueOf(price)});
            }
        } else {
            if (map.containsKey(ticker)) {
                int oldQ = Integer.parseInt(map.get(ticker)[0]);
                double oldAvg = Double.parseDouble(map.get(ticker)[1]);
                int newQ = oldQ + qtyChange;
                if (newQ <= 0) map.remove(ticker);
                else map.put(ticker, new String[]{String.valueOf(newQ), String.valueOf(oldAvg)});
            }
        }
        try (PrintWriter w = new PrintWriter(new FileWriter(file))) {
            for (String t : map.keySet()) {
                String[] p = map.get(t);
                w.println(t + "," + p[0] + "," + p[1]);
            }
        } catch (Exception ignored) {}
    }

    private void recordTransaction(String entry, double amount) {
        try (PrintWriter w = new PrintWriter(new FileWriter("transactions.txt", true))) {
            w.println(entry + " : £" + String.format("%.2f", amount));
        } catch (Exception ignored) {}
    }
}
