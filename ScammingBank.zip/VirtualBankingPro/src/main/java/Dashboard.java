package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.awt.event.*;
import screens.AccountsOverviewScreen;

public class Dashboard extends JFrame {

    private final String username;
    private JLabel currencyLabel;
    private static Dashboard instance;
    private JPanel scrollContent;
    public static User activeUser;

    public Dashboard(String username) {
        this.username = username;
        UserService userService = new UserService();
        activeUser = userService.loadUser(username);
        instance = this;
        setTitle("ScammingBank");
        setSize(880, 660);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color revolutBg = new Color(30, 35, 50);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(revolutBg);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(revolutBg);
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        JLabel profilePic = new JLabel();
        profilePic.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/profile_placeholder.png")).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
        profilePic.setCursor(new Cursor(Cursor.HAND_CURSOR));
        profilePic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new AboutMeScreen(Dashboard.this, username);
            }
        });

        JLabel logo = new JLabel();
        logo.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH)));
        logo.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel settingsIcon = new JLabel();
        settingsIcon.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/settings.png")).getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        settingsIcon.setCursor(new Cursor(Cursor.HAND_CURSOR));
        settingsIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new SettingsScreen(Dashboard.activeUser);
            }
        });

        topPanel.add(profilePic, BorderLayout.WEST);
        topPanel.add(logo, BorderLayout.CENTER);
        topPanel.add(settingsIcon, BorderLayout.EAST);

        JPanel balancePanel = new JPanel();
        balancePanel.setBackground(revolutBg);
        balancePanel.setLayout(new BoxLayout(balancePanel, BoxLayout.Y_AXIS));

        currencyLabel = new JLabel();
        currencyLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        currencyLabel.setForeground(Color.WHITE);
        currencyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        updateBalance();

        JButton accountCard = new JButton("Accounts");
        accountCard.setFont(new Font("Segoe UI", Font.BOLD, 18));
        accountCard.setForeground(Color.WHITE);
        accountCard.setBackground(new Color(0, 140, 255));
        accountCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 110, 210), 3),
                BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));
        accountCard.setAlignmentX(Component.CENTER_ALIGNMENT);
        accountCard.setFocusPainted(false);
        accountCard.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        accountCard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                accountCard.setBackground(new Color(0, 170, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                accountCard.setBackground(new Color(0, 140, 255));
            }
        });
        accountCard.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AccountsOverviewScreen(username);
            }
        });

        balancePanel.add(Box.createVerticalStrut(25));
        balancePanel.add(currencyLabel);
        balancePanel.add(Box.createVerticalStrut(15));
        balancePanel.add(accountCard);
        balancePanel.add(Box.createVerticalStrut(25));

        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 5));
        actionsPanel.setBackground(revolutBg);

        JPanel transferButton = createActionButton("Transfer", "/icons/transfer.png");
        transferButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        transferButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new TransferScreen(username);
            }
        });
        actionsPanel.add(transferButton);

        JPanel historyButton = createActionButton("History", "/icons/history.png");
        historyButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        historyButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new TransactionHistoryScreen(username);
            }
        });
        actionsPanel.add(historyButton);

        JPanel helpButton = createActionButton("Help", "/icons/help.png");
        helpButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        helpButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new HelpScreen(username);
            }
        });
        actionsPanel.add(helpButton);

        JPanel logoutButton = createActionButton("Logout", "/icons/logout.png");
        logoutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dispose();
                new LoginScreen();
            }
        });
        actionsPanel.add(logoutButton);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(revolutBg);
        centerPanel.add(Box.createVerticalGlue());

        scrollContent = new JPanel();
        scrollContent.setLayout(new BoxLayout(scrollContent, BoxLayout.Y_AXIS));
        scrollContent.setBackground(revolutBg);
        scrollContent.setBorder(BorderFactory.createEmptyBorder(0, 60, 0, 60));

        centerPanel.add(scrollContent);
        centerPanel.add(Box.createVerticalGlue());

        JPanel bottomNav = new JPanel(new GridLayout(1, 4));
        bottomNav.setBackground(new Color(20, 25, 35));
        bottomNav.setPreferredSize(new Dimension(0, 60));

        bottomNav.add(createNavButton("Invest", "/icons/invest.png"));
        bottomNav.add(createNavButton("Payments", "/icons/payments.png"));
        bottomNav.add(createNavButton("Crypto", "/icons/crypto.png"));
        bottomNav.add(createNavButton("Financial Services", "/icons/rewards.png"));

        JPanel contentWrapper = new JPanel();
        contentWrapper.setLayout(new BoxLayout(contentWrapper, BoxLayout.Y_AXIS));
        contentWrapper.setBackground(revolutBg);
        contentWrapper.add(balancePanel);
        contentWrapper.add(actionsPanel);
        contentWrapper.add(Box.createVerticalStrut(10));
        contentWrapper.add(centerPanel);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(contentWrapper, BorderLayout.CENTER);
        mainPanel.add(bottomNav, BorderLayout.SOUTH);

        add(mainPanel);

        refreshTransactionList();
    }

    private void updateBalance() {
        UserService userService = new UserService();
        User currentUser = userService.loadUser(username);
        if (currentUser != null) {
            currencyLabel.setText(String.format("£%.2f", currentUser.getBalance()));
        }
    }

    public void reloadBalance(String user) {
        if (username.equals(user)) {
            updateBalance();
        }
    }

    public void updateBalanceLabel(double balance) {
        currencyLabel.setText(String.format("£%.2f", balance));
    }

    public static void refreshBalanceExtern(String username) {
        if (instance != null) {
            instance.reloadBalance(username);
        }
    }

    public static void updateFiatDisplayExtern() {
        if (instance != null) {
            instance.updateBalance();
        }
    }

    public static void refreshTransactionListExtern() {
        if (instance != null) {
            instance.refreshTransactionList();
        }
    }

    private void refreshTransactionList() {
        scrollContent.removeAll();
        List<DashboardTransaction> recentTransactions = loadRecentTransactionsTyped(username, 5);
        if (!recentTransactions.isEmpty()) {
            for (DashboardTransaction transaction : recentTransactions) {
                JPanel txPanel = new JPanel(new BorderLayout());
                if (transaction.type.equals("in")) {
                    txPanel.setBackground(new Color(33, 64, 43));
                } else {
                    txPanel.setBackground(new Color(40, 45, 60));
                }
                txPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
                txPanel.setPreferredSize(new Dimension(0, 38));
                txPanel.setBorder(BorderFactory.createEmptyBorder(7, 16, 7, 16));
                JLabel txLabel = new JLabel(transaction.display);
                txLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
                if (transaction.type.equals("in")) {
                    txLabel.setForeground(new Color(110, 230, 150));
                } else {
                    txLabel.setForeground(Color.WHITE);
                }
                txPanel.add(txLabel, BorderLayout.CENTER);
                scrollContent.add(txPanel);
                scrollContent.add(Box.createVerticalStrut(5));
            }
        } else {
            JLabel emptyLabel = new JLabel("No recent transactions.");
            emptyLabel.setForeground(new Color(180, 180, 190));
            emptyLabel.setFont(new Font("Segoe UI", Font.ITALIC, 16));
            emptyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            scrollContent.add(emptyLabel);
        }
        scrollContent.revalidate();
        scrollContent.repaint();
    }

    private static class DashboardTransaction {
        String display;
        String type;
        DashboardTransaction(String display, String type) {
            this.display = display;
            this.type = type;
        }
    }

    private List<DashboardTransaction> loadRecentTransactionsTyped(String username, int maxCount) {
        List<DashboardTransaction> result = new ArrayList<>();
        File file = new File("transactions.txt");
        if (!file.exists()) return result;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            List<String> allLines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(username)) {
                    allLines.add(line);
                }
            }
            Collections.reverse(allLines);
            int count = 0;
            for (String tx : allLines) {
                DashboardTransaction t = parseTransactionType(tx, username);
                result.add(t);
                count++;
                if (count >= maxCount) break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    private DashboardTransaction parseTransactionType(String tx, String username) {
        String display = tx.trim();
        String type = "out";
        try {
            String[] parts = tx.split(":");
            String users = parts[0].trim();
            String amount = parts.length > 1 ? parts[1].trim() : "";
            String details = parts.length > 2 ? parts[2].trim() : "";
            if (users.contains("->")) {
                String[] us = users.split("->");
                String from = us[0].trim();
                String to = us[1].trim();
                if (username.equals(from)) {
                    display = "Sent to " + to + "  " + amount + (details.isEmpty() ? "" : ("  |  " + details));
                    type = "out";
                } else if (username.equals(to)) {
                    display = "Received from " + from + "  " + amount + (details.isEmpty() ? "" : ("  |  " + details));
                    type = "in";
                }
            }
        } catch (Exception e) {
            display = tx.trim();
            type = "out";
        }
        return new DashboardTransaction(display, type);
    }

    private JPanel createActionButton(String label, String iconPath) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(30, 35, 50));
        JLabel icon = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource(iconPath)).getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel text = new JLabel(label);
        text.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        text.setForeground(Color.WHITE);
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(icon);
        panel.add(Box.createVerticalStrut(5));
        panel.add(text);
        return panel;
    }

    private JPanel createNavButton(String label, String iconPath) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(20, 25, 35));
        JLabel icon = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource(iconPath)).getImage().getScaledInstance(24, 24, Image.SCALE_SMOOTH)));
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        JLabel text = new JLabel(label, SwingConstants.CENTER);
        text.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        text.setForeground(Color.WHITE);
        panel.add(icon, BorderLayout.CENTER);
        panel.add(text, BorderLayout.SOUTH);
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        if (label.equals("Invest")) {
            panel.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    new InvestScreen(username);
                }
            });
        } else if (label.equals("Payments")) {
            panel.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    new Payments(username).setVisible(true);
                }
            });
        } else if (label.equals("Crypto")) {
            panel.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    UserService userService = new UserService();
                    User currentUser = userService.loadUser(username);
                    if (currentUser != null) {
                        new CryptoScreen(username, currentUser.getBalance());
                    }
                }
            });
        } else if (label.equals("Financial Services")) {
            panel.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    new com.virtualbank.FinancialServicesScreen(username);
                }
            });
        }
        return panel;
    }

    public static void refreshBalance() {
        if (instance != null) {
            instance.updateBalance();
        }
    }
}
