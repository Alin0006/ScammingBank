package com.virtualbank;

public class VirtualBankingPro {

    public static void start() {
        new LoginScreen().setVisible(true);
    }
}
