package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TransactionHistoryScreen extends JFrame {

    private final String username;

    public TransactionHistoryScreen(String username) {
        this.username = username;
        setTitle("Transaction History");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        setVisible(true);
    }

    private void initUI() {
        Color bg = new Color(30, 35, 50);
        Color text = Color.WHITE;

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bg);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("Your Transaction History");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(text);
        title.setHorizontalAlignment(SwingConstants.CENTER);

        DefaultListModel<String> listModel = new DefaultListModel<>();
        List<String> history = loadTransactionHistory();
        for (String item : history) {
            listModel.addElement(item);
        }

        JList<String> list = new JList<>(listModel);
        list.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        list.setBackground(new Color(45, 50, 70));
        list.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(list);

        panel.add(title, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        add(panel);
    }

    private List<String> loadTransactionHistory() {
        List<String> result = new ArrayList<>();
        File file = new File("transactions.txt");
        if (!file.exists()) return result;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(username)) {
                    result.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Collections.reverse(result);
        return result;
    }

    public void exportUserHistory() {
        File inputFile = new File("transactions.txt");
        File outputFile = new File(username + "_exported_history.txt");

        if (!inputFile.exists()) {
            showBankDialog("No transaction history found for this account.", "Export Failed");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String line;
            boolean wroteSomething = false;
            while ((line = reader.readLine()) != null) {
                if (line.contains(username)) {
                    writer.write(line);
                    writer.newLine();
                    wroteSomething = true;
                }
            }

            if (wroteSomething) {
                showBankDialog("Your transaction history has been securely exported.\n\nSaved as: " + outputFile.getName() + "\nLocation: Application directory\n\nThank you for using ScammingBank.", "Export Completed");
            } else {
                showBankDialog("No transactions found for this user.", "Nothing to Export");
                outputFile.delete();
            }

        } catch (IOException e) {
            showBankDialog("Failed to export transaction history.", "Export Failed");
            e.printStackTrace();
        }
    }

    private void showBankDialog(String message, String title) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(400, 250);
        dialog.setLocationRelativeTo(this);
        dialog.setUndecorated(true);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(30, 35, 50));
        panel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 10, 0, 10));

        JTextArea msgArea = new JTextArea(message);
        msgArea.setWrapStyleWord(true);
        msgArea.setLineWrap(true);
        msgArea.setEditable(false);
        msgArea.setFocusable(false);
        msgArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        msgArea.setForeground(Color.WHITE);
        msgArea.setBackground(new Color(30, 35, 50));
        msgArea.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JButton okButton = new JButton("OK");
        okButton.setFocusPainted(false);
        okButton.setBackground(new Color(40, 90, 160));
        okButton.setForeground(Color.WHITE);
        okButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        okButton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        okButton.addActionListener(e -> dialog.dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(30, 35, 50));
        buttonPanel.add(okButton);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(msgArea, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(panel);
        dialog.setVisible(true);
    }
}
