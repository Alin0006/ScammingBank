package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Payments extends JFrame {

    private final String username;

    public Payments(String username) {
        this.username = username;

        setTitle("Payments");
        setSize(600, 480);
        setLocationRelativeTo(null);
        setUndecorated(true);
        getContentPane().setBackground(new Color(15, 22, 38));
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(null);
        topPanel.setPreferredSize(new Dimension(600, 100));
        topPanel.setBackground(new Color(15, 22, 38));

        JLabel logo = new JLabel();
        logo.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/icons/Scamming Bank.png")).getImage().getScaledInstance(90, 90, Image.SCALE_SMOOTH)));
        logo.setBounds(260, 5, 100, 90);
        topPanel.add(logo);

        JButton closeBtn = new JButton("X");
        closeBtn.setBounds(550, 10, 40, 30);
        closeBtn.setBackground(new Color(120, 0, 0));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setFocusPainted(false);
        topPanel.add(closeBtn);

        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(new Color(15, 22, 38));
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Payments");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton internationalBtn = new JButton("International");
        internationalBtn.setMaximumSize(new Dimension(200, 45));
        internationalBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        internationalBtn.setBackground(new Color(32, 42, 68));
        internationalBtn.setForeground(Color.WHITE);
        internationalBtn.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        internationalBtn.setFocusPainted(false);

        JButton directDebitsBtn = new JButton("Direct Debits");
        directDebitsBtn.setMaximumSize(new Dimension(200, 45));
        directDebitsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        directDebitsBtn.setBackground(new Color(32, 42, 68));
        directDebitsBtn.setForeground(Color.WHITE);
        directDebitsBtn.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        directDebitsBtn.setFocusPainted(false);

        JButton scheduledBtn = new JButton("Scheduled Payments");
        scheduledBtn.setMaximumSize(new Dimension(200, 45));
        scheduledBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        scheduledBtn.setBackground(new Color(32, 42, 68));
        scheduledBtn.setForeground(Color.WHITE);
        scheduledBtn.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        scheduledBtn.setFocusPainted(false);

        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(title);
        contentPanel.add(Box.createVerticalStrut(25));
        contentPanel.add(internationalBtn);
        contentPanel.add(Box.createVerticalStrut(15));
        contentPanel.add(directDebitsBtn);
        contentPanel.add(Box.createVerticalStrut(15));
        contentPanel.add(scheduledBtn);
        contentPanel.add(Box.createVerticalGlue());

        add(topPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        internationalBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new InternationalPayments().setVisible(true);
            }
        });

        directDebitsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new DirectDebits(username).setVisible(true);
            }
        });

        scheduledBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ScheduledPayments(username).setVisible(true);
            }
        });

        closeBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
