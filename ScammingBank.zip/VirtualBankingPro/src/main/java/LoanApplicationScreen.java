package com.virtualbank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class LoanApplicationScreen extends JFrame {
    public LoanApplicationScreen() {
        setTitle("Apply for a Loan");
        setSize(520, 580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(25, 30, 50));
        panel.setLayout(null);

        JLabel title = new JLabel("Apply for a Loan");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        title.setBounds(150, 20, 250, 30);
        panel.add(title);

        JLabel nameLabel = new JLabel("Full Name:");
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setBounds(40, 70, 120, 24);
        panel.add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(160, 70, 300, 26);
        panel.add(nameField);

        JLabel dobLabel = new JLabel("Date of Birth (DD-MM-YYYY):");
        dobLabel.setForeground(Color.WHITE);
        dobLabel.setBounds(40, 110, 170, 24);
        panel.add(dobLabel);

        JTextField dobField = new JTextField();
        dobField.setBounds(220, 110, 240, 26);
        panel.add(dobField);

        JLabel employmentLabel = new JLabel("Employment Status:");
        employmentLabel.setForeground(Color.WHITE);
        employmentLabel.setBounds(40, 150, 120, 24);
        panel.add(employmentLabel);

        String[] employmentOptions = {"Employed", "Self-Employed", "Unemployed", "Student", "Retired"};
        JComboBox<String> employmentBox = new JComboBox<>(employmentOptions);
        employmentBox.setBounds(160, 150, 300, 26);
        panel.add(employmentBox);

        JLabel incomeLabel = new JLabel("Monthly Income (£):");
        incomeLabel.setForeground(Color.WHITE);
        incomeLabel.setBounds(40, 190, 120, 24);
        panel.add(incomeLabel);

        JTextField incomeField = new JTextField();
        incomeField.setBounds(160, 190, 300, 26);
        panel.add(incomeField);

        JLabel reasonLabel = new JLabel("Reason for Loan:");
        reasonLabel.setForeground(Color.WHITE);
        reasonLabel.setBounds(40, 230, 120, 24);
        panel.add(reasonLabel);

        JTextArea reasonArea = new JTextArea();
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(reasonArea);
        scrollPane.setBounds(160, 230, 300, 60);
        panel.add(scrollPane);

        JLabel amountLabel = new JLabel("Loan Amount (£):");
        amountLabel.setForeground(Color.WHITE);
        amountLabel.setBounds(40, 300, 120, 24);
        panel.add(amountLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(160, 300, 300, 26);
        panel.add(amountField);

        JLabel yearsLabel = new JLabel("Years at Current Job:");
        yearsLabel.setForeground(Color.WHITE);
        yearsLabel.setBounds(40, 340, 140, 24);
        panel.add(yearsLabel);

        JComboBox<Integer> yearsBox = new JComboBox<>();
        for (int i = 0; i <= 50; i++) yearsBox.addItem(i);
        yearsBox.setBounds(180, 340, 60, 26);
        panel.add(yearsBox);

        JLabel monthsLabel = new JLabel("Months:");
        monthsLabel.setForeground(Color.WHITE);
        monthsLabel.setBounds(260, 340, 60, 24);
        panel.add(monthsLabel);

        JComboBox<Integer> monthsBox = new JComboBox<>();
        for (int i = 0; i <= 11; i++) monthsBox.addItem(i);
        monthsBox.setBounds(320, 340, 60, 26);
        panel.add(monthsBox);

        JButton submitButton = new JButton("Submit Application");
        submitButton.setBounds(160, 400, 200, 40);
        submitButton.setBackground(new Color(0, 150, 100));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        panel.add(submitButton);

        submitButton.addActionListener((ActionEvent e) -> {
            String name = nameField.getText();
            String dob = dobField.getText();
            String employment = (String) employmentBox.getSelectedItem();
            String income = incomeField.getText();
            String reason = reasonArea.getText();
            String amount = amountField.getText();
            int years = (int) yearsBox.getSelectedItem();
            int months = (int) monthsBox.getSelectedItem();

            if (name.isEmpty() || dob.isEmpty() || income.isEmpty() || reason.isEmpty() || amount.isEmpty()) {
                showSuccessDialog("All fields must be filled", false);
                return;
            }
            if (!dob.matches("\\d{2}-\\d{2}-\\d{4}")) {
                showSuccessDialog("Date of Birth must be DD-MM-YYYY", false);
                return;
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("loan_applications.txt", true))) {
                writer.write("Name: " + name);
                writer.newLine();
                writer.write("DOB: " + dob);
                writer.newLine();
                writer.write("Employment: " + employment);
                writer.newLine();
                writer.write("Monthly Income: £" + income);
                writer.newLine();
                writer.write("Reason: " + reason);
                writer.newLine();
                writer.write("Amount: £" + amount);
                writer.newLine();
                writer.write("Job Duration: " + years + " years and " + months + " months");
                writer.newLine();
                writer.write("--------------------------------------------------");
                writer.newLine();
            } catch (IOException ex) {
                showSuccessDialog("Failed to save application", false);
                return;
            }
            showSuccessDialog("Loan application submitted successfully!", true);
            dispose();
        });

        add(panel);
        setVisible(true);
    }

    private void showSuccessDialog(String message, boolean okOnly) {
        JDialog dialog = new JDialog(this, "Info", true);
        dialog.setSize(340, 160);
        dialog.setLayout(new BorderLayout());
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 245, 245));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel msg = new JLabel(message, SwingConstants.CENTER);
        msg.setFont(new Font("Segoe UI", Font.BOLD, 14));
        msg.setForeground(new Color(30, 60, 90));
        msg.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton ok = new JButton("OK");
        ok.setBackground(new Color(30, 60, 90));
        ok.setForeground(Color.WHITE);
        ok.setFocusPainted(false);
        ok.setAlignmentX(Component.CENTER_ALIGNMENT);
        ok.addActionListener(ev -> dialog.dispose());

        panel.add(Box.createVerticalStrut(18));
        panel.add(msg);
        panel.add(Box.createVerticalStrut(20));
        panel.add(ok);
        panel.add(Box.createVerticalStrut(10));

        dialog.add(panel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }
}
