package screens;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.virtualbank.CreditCardStatusScreen;
import com.virtualbank.OverdraftStatusScreen;
import screens.MortgageStatusScreen;

public class AccountsOverviewScreen extends JFrame {
    private String username;

    public AccountsOverviewScreen(String username) {
        this.username = username;
        setTitle("Accounts Overview");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(20, 20, 20));

        JLabel titleLabel = new JLabel("Your Accounts");
        titleLabel.setBounds(120, 20, 200, 30);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel);

        JButton creditCardButton = new JButton("Credit Card");
        creditCardButton.setBounds(100, 70, 200, 30);
        creditCardButton.setBackground(new Color(0, 120, 255));
        creditCardButton.setForeground(Color.WHITE);
        creditCardButton.setFocusPainted(false);
        add(creditCardButton);

        JButton mortgageButton = new JButton("Mortgage");
        mortgageButton.setBounds(100, 120, 200, 30);
        mortgageButton.setBackground(new Color(0, 120, 255));
        mortgageButton.setForeground(Color.WHITE);
        mortgageButton.setFocusPainted(false);
        add(mortgageButton);

        JButton overdraftButton = new JButton("Overdraft");
        overdraftButton.setBounds(100, 170, 200, 30);
        overdraftButton.setBackground(new Color(0, 120, 255));
        overdraftButton.setForeground(Color.WHITE);
        overdraftButton.setFocusPainted(false);
        add(overdraftButton);

        creditCardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CreditCardStatusScreen(username);
            }
        });

        mortgageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MortgageStatusScreen(username);
            }
        });

        overdraftButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new OverdraftStatusScreen(username);
            }
        });

        setVisible(true);
    }
}
