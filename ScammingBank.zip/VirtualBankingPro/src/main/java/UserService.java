package com.virtualbank;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    private static final String FILE_PATH = "users.txt";

    public boolean register(User user) {
        if (userExists(user.getUsername()) || emailExists(user.getEmail())) {
            return false;
        }
        try (FileWriter fw = new FileWriter(FILE_PATH, true)) {
            fw.write(user.getUsername() + ";" + user.getEmail() + ";" + user.getPassword() + ";" + user.getBalance() + ";" + user.getStatus() + ";" + user.getLanguage() + ";" + user.isDarkMode() + "\n");
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean authenticate(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 5 && parts[0].equals(username) && parts[2].equals(password)) {
                    return parts[4].equalsIgnoreCase("active");
                }
            }
        } catch (IOException e) {
            return false;
        }
        return false;
    }

    public boolean userExists(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 1 && parts[0].equals(username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            return false;
        }
        return false;
    }

    public boolean emailExists(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 2 && parts[1].equalsIgnoreCase(email)) {
                    return true;
                }
            }
        } catch (IOException e) {
            return false;
        }
        return false;
    }

    public User loadUser(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 5 && parts[0].equals(username)) {
                    double balance = Double.parseDouble(parts[3]);
                    String status = parts[4];
                    String language = parts.length >= 6 ? parts[5] : "English";
                    boolean darkMode = parts.length >= 7 && Boolean.parseBoolean(parts[6]);
                    return new User(parts[0], parts[1], parts[2], balance, status, language, darkMode);
                }
            }
        } catch (IOException | NumberFormatException e) {
            return null;
        }
        return null;
    }

    public List<User> loadAllUsers() {
        List<User> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 5) {
                    double balance = Double.parseDouble(parts[3]);
                    String status = parts[4];
                    String language = parts.length >= 6 ? parts[5] : "English";
                    boolean darkMode = parts.length >= 7 && Boolean.parseBoolean(parts[6]);
                    users.add(new User(parts[0], parts[1], parts[2], balance, status, language, darkMode));
                }
            }
        } catch (IOException | NumberFormatException e) {
            return users;
        }
        return users;
    }

    public boolean deleteUser(String username) {
        List<User> users = loadAllUsers();
        boolean removed = users.removeIf(user -> user.getUsername().equals(username));
        if (!removed) return false;
        return saveAllUsers(users);
    }

    public boolean setStatus(String username, String newStatus) {
        List<User> users = loadAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                user.setStatus(newStatus);
                return saveAllUsers(users);
            }
        }
        return false;
    }

    private boolean saveAllUsers(List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (User user : users) {
                writer.write(user.getUsername() + ";" + user.getEmail() + ";" + user.getPassword() + ";" + user.getBalance() + ";" + user.getStatus() + ";" + user.getLanguage() + ";" + user.isDarkMode());
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean updateBalance(String username, double amountToAdd) {
        List<User> users = loadAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                user.setBalance(user.getBalance() + amountToAdd);
                return saveAllUsers(users);
            }
        }
        return false;
    }

    public boolean saveUser(User user) {
        List<User> users = loadAllUsers();
        boolean found = false;
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(user.getUsername())) {
                users.set(i, user);
                found = true;
                break;
            }
        }
        if (!found) users.add(user);
        return saveAllUsers(users);
    }
}
